# RetailCo Data Warehouse — Week 3

## 1. Project Overview
This project implements a dimensional data warehouse for RetailCo transaction data. It demonstrates data staging, transformation, dimensional modelling, fact-table loading, and data-quality validation.

## 2. Technology
- SQL
- PostgreSQL 18
- CSV source data

**Platform note:** The Week 3 brief specifies MySQL. PostgreSQL was used for execution because installation restrictions prevented setting up MySQL locally. SQL syntax and validation results are therefore PostgreSQL-based.

## 3. Source Dataset
- File: `retailco_raw_20240115.csv`
- Source rows: 52
- Source columns: 16
- Distinct transaction IDs: 50
- Distinct store IDs: 10
- Distinct product codes: 49

## 4. Warehouse Design
Dimension tables:
- `dim_date`
- `dim_store`
- `dim_product`
- `dim_customer`
- `dim_cashier`

Fact table:
- `fact_sales`

The fact table stores transaction measures and foreign keys to the relevant dimensions. `source_row_number` distinguishes individual source records, including duplicate transaction IDs.

## 5. Data Pipeline
1. Load the CSV into `staging_retailco`.
2. Standardize transaction dates and numeric fields in `transformed_retailco`.
3. Populate the five dimension tables.
4. Load transaction records into `fact_sales`.
5. Run SQL data-quality and reconciliation checks.

## 6. Data Quality Findings
- Two exact duplicate source rows were identified.
- Transaction IDs `TXN10001` and `TXN10007` each occur twice.
- Two customer IDs and two cashier IDs are missing.
- Source dates use multiple formats, including `YYYY-MM-DD`, `DD-MM-YYYY`, and `DD/MM/YYYY`.
- The original staging data is retained; duplicate records are not silently deleted.

## 7. Validation Results
- Staging rows: 52
- Transformed rows: 52
- Fact rows: 52
- Invalid transformed dates: 0
- Total quantity in fact table: 121
- Total sales amount: ₹130,473.00
- Missing date, store, and product dimension references: 0
- Transformed and fact sales totals: reconciled successfully

## 8. SQL Files
- `SPEC.md` — data model specification
- `schema.sql` — warehouse table definitions
- `staging.sql` — staging table definition
- `transform.sql` — data transformation
- `load_dimensions.sql` — dimension loading
- `load_fact.sql` — fact-table loading
- `validation.sql` — data-quality and reconciliation checks

## 9. Execution
Run the SQL files in the following order from `psql`, connected to the `retailco_dw` database:

1. `schema.sql`
2. `staging.sql`
3. Load the source CSV into `staging_retailco` using `\copy`.
4. `transform.sql`
5. `load_dimensions.sql`
6. `load_fact.sql`
7. `validation.sql`

Update the file paths in the `\i` and `\copy` commands to match the local environment.

## 10. Conclusion
The RetailCo dataset was successfully staged, transformed, modelled, and loaded into a dimensional warehouse using PostgreSQL. Validation confirmed row-count reconciliation, date standardization, dimension-reference integrity, and sales-total reconciliation.