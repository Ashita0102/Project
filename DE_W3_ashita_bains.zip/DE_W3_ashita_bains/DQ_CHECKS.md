# Week 3 Data Quality Checks

## Source Dataset
- File: `retailco_raw_20240115.csv`
- Source rows: 52
- Source columns: 16

## Checks and Findings

| Check | Result |
|---|---|
| Source row count | 52 |
| Distinct transaction IDs | 50 |
| Exact duplicate rows | 2 |
| Duplicate transaction IDs | TXN10001 and TXN10007 |
| Missing customer IDs | 2 |
| Missing cashier IDs | 2 |
| Distinct store IDs | 10 |
| Distinct product codes | 49 |
| Invalid dates after transformation | 0 |
| Missing quantity after transformation | 0 |
| Missing unit price after transformation | 0 |
| Missing total amount after transformation | 0 |

## Handling Decisions
- Original source records were preserved in staging.
- Duplicate transaction IDs were not used as a unique key.
- Dates were standardized using the observed source formats.
- Missing customer and cashier IDs were not fabricated.
- Fact-table dimension references were validated.

## Outcome
The checks passed for the reported transformation and fact-table loading results. The duplicate source records and missing identifiers remain documented findings rather than being silently removed.
