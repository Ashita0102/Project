# Week 3 Validation Report

## Execution Environment
- Database: PostgreSQL 18
- Database name: `retailco_dw`

## Row-Count Reconciliation

| Table | Rows |
|---|---:|
| `staging_retailco` | 52 |
| `transformed_retailco` | 52 |
| `fact_sales` | 52 |

## Fact Table Results

| Metric | Result |
|---|---:|
| Total quantity | 121 |
| Total sales amount | INR 130,473.00 |

## Validation Findings
- All 52 source records were transformed.
- All transformed dates were valid after the date-format correction.
- Missing date, store, and product dimension references: 0.
- Transformed and fact sales totals reconciled successfully.
- Duplicate transaction IDs were retained and documented.
- Missing customer and cashier identifiers were not fabricated.

## Platform Limitation
The Week 3 brief specifies MySQL. Execution was performed using PostgreSQL 18 due to company device restrictions. The results in this report are PostgreSQL execution results, not a MySQL execution test.
