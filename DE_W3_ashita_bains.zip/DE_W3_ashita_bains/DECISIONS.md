# Week 3 Design Decisions

## 1. SQL Platform
PostgreSQL 18 was used for execution because company security restrictions prevented installing MySQL. The required platform difference is documented in the README.

## 2. Data Staging
The original CSV was loaded into `staging_retailco` with source values retained as text. This preserves the source representation for inspection and validation.

## 3. Data Transformation
A separate `transformed_retailco` table was created. Transaction dates were standardized to PostgreSQL DATE values, and numeric columns were converted to appropriate numeric types.

## 4. Date Formats
The transformation supports `YYYY-MM-DD`, `DD-MM-YYYY`, and `DD/MM/YYYY`, based on formats observed in the source dataset.

## 5. Fact Table Grain
The fact table retains one row per source record. `source_row_number` distinguishes source rows, so repeated transaction IDs do not automatically cause records to be discarded.

## 6. Missing Identifiers
Missing customer and cashier IDs were not replaced with invented identifiers. Their foreign-key assignments can remain NULL.

## 7. Sales Amount
The source-provided `total_amount_inr` was retained rather than recalculated, preserving the reported source measure.

## 8. Validation
Row counts, date validity, dimension references, duplicate transaction IDs, quantity totals, and sales totals were checked.
