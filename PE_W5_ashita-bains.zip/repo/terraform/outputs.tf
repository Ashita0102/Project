
output "configured_project_id" {
  description = "Google Cloud project ID selected for this deployment"
  value       = var.project_id
}

output "configured_region" {
  description = "Google Cloud region selected for this deployment"
  value       = var.region
}
