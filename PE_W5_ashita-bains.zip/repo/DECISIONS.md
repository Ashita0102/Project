# Week 5 Decisions — RetailCo Platform Engineering

## 1. Containerization

**Decision:** Package the existing RetailCo ingestion script using Docker rather than changing its ingestion logic.

**Reason:** This preserves the existing workflow while making the script runnable in a reproducible container environment.

## 2. Python Dependencies

**Decision:** Install pandas in the Docker image.

**Reason:** The ingestion script requires pandas. The initial image lacked this dependency, so it was added to the Dockerfile and the image was rebuilt and tested.

## 3. Container File Layout

**Decision:** Keep the authoritative Dockerfile at the repository root.

**Reason:** The Week 5 deliverable requires `repo/Dockerfile`. The previous `docker/Dockerfile` was moved to the root location.

## 4. Generated Output and Git Hygiene

**Decision:** Exclude generated ingestion output and Terraform local working files from Git.

**Reason:** The staging CSV can be regenerated, and Terraform state or local files should not be committed. A `.gitignore` file records these exclusions.

## 5. Terraform Configuration

**Decision:** Keep the Google Cloud project ID configurable and use a configurable region with a default value of `asia-south1`.

**Reason:** Environment-specific settings should not be hardcoded, and credentials or service-account keys should not be stored in the repository.

## 6. Cloud Deployment Limitation

**Decision:** Do not attempt to provision GCP resources without authorized project access.

**Reason:** The project is not currently available to the developer. Terraform initialization and validation succeeded locally, but planning against an authorized project and the apply/destroy/reapply lifecycle remain unverified.

## 7. AI Assistance

**Decision:** Use AI assistance for step-by-step troubleshooting, Docker and Terraform configuration guidance, and documentation drafting, while checking command results locally.

**Reason:** The implementation decisions were based on observed terminal output and the project specification. Deployment claims are limited to what has actually been verified.