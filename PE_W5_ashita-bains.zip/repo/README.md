# RetailCo Ingestion — Week 5

## Overview

This project packages the RetailCo CSV ingestion script in a Docker container and prepares Terraform configuration for Google Cloud Platform (GCP) infrastructure.

The ingestion script processes the RetailCo raw CSV dataset and produces a staging CSV file.

## Repository Structure

```text
repo/
├── Dockerfile
├── .dockerignore
├── .gitignore
├── ingest.py
├── README.md
├── STATUS.md
├── DECISIONS.md
├── specs/
├── terraform/
│   ├── main.tf
│   ├── variables.tf
│   ├── outputs.tf
│   └── .terraform.lock.hcl
└── data/                 # Generated locally; excluded from Git
```

## Prerequisites

- Docker Desktop
- Terraform CLI
- PowerShell on Windows
- An authorized GCP project and the necessary IAM permissions for cloud deployment

## Build the Docker Image

Run these commands from the repository root:

```powershell
docker build -t retailco-ingest:w5 .
```

## Run the Ingestion Container

The input CSV is mounted read-only, and the generated staging CSV is written to a local output directory.

```powershell
New-Item -ItemType Directory -Force .\data

docker run --rm `
  -v "${HOME}\OneDrive\Desktop\DE_W2_ashita_bains\data:/input:ro" `
  -v "${PWD}\data:/output" `
  retailco-ingest:w5 `
  /input/retailco_raw_20240115.csv `
  /output/retailco_staging.csv
```

Update the input path if the raw CSV is stored elsewhere.

## Terraform Commands

Run these commands from the repository root.

Format the configuration:

```powershell
terraform -chdir=terraform fmt
```

Initialize Terraform:

```powershell
terraform -chdir=terraform init
```

Validate the configuration:

```powershell
terraform -chdir=terraform validate
```

Review the proposed infrastructure changes:

```powershell
terraform -chdir=terraform plan -var="project_id=YOUR_GCP_PROJECT_ID"
```

Only use an actual authorized project ID. Review the plan before applying any changes.

When authorized GCP access is available, use the reviewed plan to guide `apply`, `destroy`, and reapply testing. Do not run these commands against an unapproved project.

## GCP Access Limitation

At the time of this submission, an authorized GCP project is not available to the developer. The Terraform configuration has been initialized and validated locally, but cloud provisioning and the apply/destroy/reapply lifecycle have not been verified.

The provider, project variable, region variable, and configuration outputs are present. The exact cloud resources still need to be selected according to the capstone requirements before deployment.

## Security and Generated Files

- Do not commit credentials, service-account keys, or secret values.
- Terraform local working files and state files are excluded through `.gitignore`.
- Generated ingestion output under `data/` is excluded from Git.
- Do not apply Terraform changes until the project, permissions, and proposed plan have been reviewed.