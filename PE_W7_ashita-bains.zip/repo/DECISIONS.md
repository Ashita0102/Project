# RetailCo Capstone - Engineering Decisions

## 1. Containerization

Decision: Package the RetailCo ingestion application
using Docker.

Reason: Provide a consistent runtime environment
and simplify Kubernetes deployment.

## 2. Kubernetes Deployment

Decision: Use Helm for application deployment.

Reason: Maintain reusable deployment templates,
health probes, resource limits and environment values.

## 3. Local Kubernetes Environment

Decision: Use Docker Desktop Kubernetes.

Reason: Minikube installation was restricted on the
BYOD device. Docker Desktop provided an available
local Kubernetes environment.

## 4. Automated Quality Gates

Decision: Run unit tests before building and
deploying the application.

Reason: Prevent faulty application changes from
reaching development or staging.

Validation: An intentionally failing test blocked
both environment deployments.

## 5. Commit-Triggered CI/CD

Decision: Use a version-controlled Git post-commit
hook to execute the local pipeline.

Reason: Demonstrate automated deployment without
requiring active cloud infrastructure.

Trade-off: Local hooks require configuration and
cannot undo an existing Git commit. This is not
equivalent to remote GitOps reconciliation.

## 6. Build Traceability

Decision: Build from an isolated Git archive and
tag Docker images using the commit SHA.

Reason: Exclude uncommitted files and associate
application images with committed source.

Validation: Docker image revision metadata matched
the full Git commit SHA.

## 7. Environment Promotion

Decision: Separate development and staging using
Kubernetes namespaces and Helm releases.

Reason: Promote the same tested application image
only after development health verification passes.

## 8. Rollback Strategy

Decision: Use Helm automatic rollback for failed
upgrades and explicit rollback for failures in the
subsequent deployment health gate.

Reason: Restore the previous release and prevent
promotion of rejected development deployments.

Validation: A simulated development health failure
triggered successful rollback and blocked staging.

## 9. Infrastructure as Code

Decision: Manage cloud infrastructure with Terraform.

Reason: Define networking, Kubernetes, IAM and
supporting resources declaratively.

Validation: Actual provisioning and destruction
were completed.

## 10. Cloud Networking

Decision: Use a custom VPC, private GKE nodes,
restricted control-plane access and Cloud NAT.

Reason: Reduce unnecessary public exposure while
allowing required outbound connectivity.

## 11. Identity and Access Management

Decision: Use dedicated service accounts, scoped
IAM permissions and Workload Identity.

Reason: Reduce unnecessary privileges and avoid
long-lived service-account credentials.

## 12. Secrets Management

Decision: Retrieve application configuration from
Google Secret Manager using Workload Identity.

Reason: Keep secret values outside source code
and container images.

Limitation: Retrieved configuration is validated
but does not yet control ingestion behavior.

## 13. Data Protection

Decision: Use a synthetic CSV fixture for the
updated application container.

Reason: Avoid including original business datasets
in the updated cloud build.

## 14. Cloud Cost Management

Decision: Destroy cloud infrastructure after
collecting runtime verification evidence.

Reason: Prevent unnecessary consumption of trial
credits.

Trade-off: Live cloud demonstrations require
authorized infrastructure recreation.

## 15. Evidence and Security

Decision: Preserve execution logs and redact
selected personal cloud identifiers.

Reason: Support evaluation without unnecessarily
exposing account information.

Credential-pattern checks were performed, but
these are not a comprehensive security audit.

## 16. AI Assistance and Human Verification

AI assistance was used for implementation guidance,
configuration drafting, troubleshooting, testing
strategies and documentation.

Commands were executed locally and results were
checked against terminal output.

An initial approach using Docker template formatting
failed because of PowerShell quotation handling.
The approach was replaced with JSON metadata parsing,
which successfully verified image traceability.

The initial working-directory build approach was
also replaced with an isolated committed-source
snapshot to improve traceability.

Implementation claims are limited to observed
results. Outstanding requirements are documented
in STATUS.md.

## 17. Remaining Trade-offs

- Remote GitOps reconciliation is incomplete.
- Automated GKE deployment is incomplete.
- Independent staging rollback testing is pending.
- Container dependencies are not fully pinned.
- Helm configuration is not isolated from the
  working directory.
- Fresh-clone execution requires verification.
- The overall 85 percent deployment reliability
  target has not been established.
