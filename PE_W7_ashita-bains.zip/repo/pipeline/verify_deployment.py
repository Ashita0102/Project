import subprocess
import sys

context = "docker-desktop"
namespace = sys.argv[1] if len(sys.argv) > 1 else "default"
release = sys.argv[2] if len(sys.argv) > 2 else "retailco"
deployment = f"deployment/{release}-retailco-chart"

print(f"Verifying environment: {namespace}", flush=True)

commands = [
    [
        "kubectl", "--context", context,
        "rollout", "status", deployment,
        "-n", namespace, "--timeout=180s"
    ],
    [
        "kubectl", "--context", context,
        "wait", "--for=condition=Available",
        deployment, "-n", namespace,
        "--timeout=180s"
    ]
]

for command in commands:
    print("Running:", " ".join(command), flush=True)
    result = subprocess.run(command)

    if result.returncode != 0:
        print("DEPLOYMENT HEALTH GATE FAILED.")
        sys.exit(1)

print("DEPLOYMENT HEALTH GATE PASSED.")
sys.exit(0)
