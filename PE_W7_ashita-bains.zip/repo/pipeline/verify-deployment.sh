﻿#!/usr/bin/env bash
set -euo pipefail

NAMESPACE="${NAMESPACE:-default}"
DEPLOYMENT="${DEPLOYMENT:-retailco-retailco-chart}"
TIMEOUT="${TIMEOUT:-180s}"

echo "Checking deployment rollout..."
kubectl rollout status "deployment/${DEPLOYMENT}" \
  --namespace "${NAMESPACE}" \
  --timeout="${TIMEOUT}"

echo "Checking deployment availability..."
kubectl wait \
  --for=condition=Available \
  "deployment/${DEPLOYMENT}" \
  --namespace "${NAMESPACE}" \
  --timeout="${TIMEOUT}"

echo "Deployment health gate PASSED."
