import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parent.parent

try:
    sha = subprocess.check_output(
        ["git", "rev-parse", "HEAD"],
        cwd=root, text=True
    ).strip()

    print(f"Building committed source: {sha}", flush=True)

    with tempfile.TemporaryDirectory() as temp:
        archive = Path(temp) / "source.zip"
        source = Path(temp) / "source"
        source.mkdir()

        subprocess.run([
            "git", "archive",
            "--format=zip",
            f"--output={archive}",
            sha,
            "app.py",
            "ingest.py",
            "Dockerfile",
            ".dockerignore",
            "fixtures",
            "app/tests"
        ], cwd=root, check=True)

        with zipfile.ZipFile(archive) as bundle:
            bundle.extractall(source)

        print("COMMITTED SOURCE SNAPSHOT CREATED.", flush=True)

        print("STAGE 1: Automated unit tests", flush=True)

        result = subprocess.run([
            sys.executable, "-m", "unittest",
            "discover", "-s", "app/tests",
            "-p", "test_*.py", "-v"
        ], cwd=source)

        if result.returncode != 0:
            raise RuntimeError("QUALITY GATE FAILED. Build blocked.")

        print("QUALITY GATE PASSED.", flush=True)
        print("STAGE 2: Docker build", flush=True)

        subprocess.run([
            "docker", "build",
            "--label", f"org.opencontainers.image.revision={sha}",
            "-t", "retailco-local-ci:latest",
            "."
        ], cwd=source, check=True)

    print("LOCAL CI PIPELINE PASSED.")
    sys.exit(0)

except (subprocess.CalledProcessError, RuntimeError) as error:
    print("LOCAL CI PIPELINE FAILED:", error)
    sys.exit(1)
