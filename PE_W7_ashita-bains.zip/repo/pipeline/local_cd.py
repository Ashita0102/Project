import json
import subprocess
import sys
from pathlib import Path

root = Path(__file__).resolve().parent.parent
context = "docker-desktop"

def run(command):
    print("Running:", " ".join(command), flush=True)
    subprocess.run(command, cwd=root, check=True)

def previous_revision(release, namespace):
    output = subprocess.check_output(
        ["helm", "history", release,
         "--kube-context", context,
         "-n", namespace, "-o", "json"],
        cwd=root, text=True
    )
    history = json.loads(output)
    revisions = [
        int(item["revision"])
        for item in history
        if item["status"] == "deployed"
    ]
    if not revisions:
        raise RuntimeError("No healthy rollback baseline found.")
    return max(revisions)

def deploy(release, namespace, values, sha):
    previous = previous_revision(release, namespace)
    print(f"Rollback baseline: {previous}", flush=True)

    run([
        "helm", "upgrade", release, "./chart",
        "--kube-context", context,
        "--namespace", namespace,
        "-f", values,
        "--set", "image.repository=retailco-local-ci",
        "--set-string", f"image.tag={sha}",
        "--set", "image.pullPolicy=Never",
        "--rollback-on-failure",
        "--wait", "--timeout", "180s"
    ])

    try:
        run([
            sys.executable,
            "pipeline/verify_deployment.py",
            namespace, release
        ])
    except subprocess.CalledProcessError:
        print("HEALTH GATE FAILED. Starting rollback.", flush=True)

        run([
            "helm", "rollback", release, str(previous),
            "--kube-context", context,
            "--namespace", namespace,
            "--wait", "--timeout", "180s"
        ])

        run([
            sys.executable,
            "pipeline/verify_deployment.py",
            namespace, release
        ])

        print("AUTOMATIC HEALTH GATE ROLLBACK PASSED.", flush=True)
        raise RuntimeError("Deployment rejected and rolled back.")

try:
    if subprocess.check_output(
        ["git", "status", "--porcelain", "--untracked-files=no"],
        cwd=root, text=True
    ).strip():
        raise RuntimeError("Commit tracked changes before deployment.")

    sha = subprocess.check_output(
        ["git", "rev-parse", "--short", "HEAD"],
        cwd=root, text=True
    ).strip()

    print("STAGE 1: CI quality gate", flush=True)
    run([sys.executable, "pipeline/local_ci.py"])

    print("STAGE 2: Version image", flush=True)
    run([
        "docker", "tag",
        "retailco-local-ci:latest",
        f"retailco-local-ci:{sha}"
    ])

    print("STAGE 3: Development deployment and health gate", flush=True)
    deploy("retailco", "default", "gitops/values-dev.yaml", sha)

    print("STAGE 4: Staging promotion and health gate", flush=True)
    deploy(
        "retailco-staging",
        "retailco-staging",
        "gitops/values-staging.yaml",
        sha
    )

    print("STAGING PROMOTION PASSED.", flush=True)
    print("LOCAL CD PIPELINE PASSED.", flush=True)
    sys.exit(0)

except (subprocess.CalledProcessError, RuntimeError) as error:
    print("LOCAL CD PIPELINE FAILED:", error)
    sys.exit(1)
