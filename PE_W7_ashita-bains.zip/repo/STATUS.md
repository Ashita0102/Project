# RetailCo Capstone - Milestone Status

## Week 5 - Containerization and Infrastructure

- Docker containerization completed.
- CSV ingestion tested.
- Terraform configuration prepared.
- Infrastructure provisioning subsequently verified.

## Week 6 - Kubernetes Deployment

- Helm chart implemented and validated.
- Application health and readiness endpoints tested.
- Local Kubernetes deployment verified.
- GKE deployment subsequently verified.
- Kubernetes self-healing demonstrated on GKE.
- HPA scale-up from 2 to 5 replicas demonstrated.
- HPA scale-down from 5 to 2 replicas demonstrated.

These additional cloud validations were completed
after the original Week 6 milestone.

## Week 7 - CI/CD and Deployment Automation

### Verified

- Pipeline specification committed before implementation.
- Automated unit tests and quality gates.
- Commit-triggered local CI/CD.
- Isolated committed-source Docker builds.
- Commit SHA image tagging and metadata verification.
- Automated development deployment.
- Health-gated staging promotion.
- Failed unit tests block both environment deployments.
- Manual and automatic Helm rollback demonstrated.
- Automatic development rollback after simulated
  post-deployment health-gate failure.
- Successful pipeline recovery after failure testing.
- Manual Google Cloud Build execution.
- Artifact Registry image publishing.

### Outstanding

- Remote GitOps controller and reconciliation.
- Cloud-based commit-triggered CI/CD.
- Automated GKE deployment and promotion.
- Overall deployment reliability target of 85 percent
  has not been established.
- Independent staging rollback failure test.
- Fresh-clone execution verification.

## Week 8 - Security and Cloud Networking

### Verified

- Security and networking specification committed.
- Terraform-managed VPC and subnet.
- Private GKE nodes.
- Restricted control-plane access.
- Cloud Router and Cloud NAT.
- Dedicated service accounts and scoped IAM roles.
- Workload Identity configuration.
- Secret Manager integration.
- Application configuration retrieval from Secret Manager.
- Internal ClusterIP service networking.
- Actual Terraform provisioning and destruction.
- Cloud resource cleanup verification.

### Limitations

- Some infrastructure code was prepared before the
  security specification was committed.
- Retrieved secret configuration is validated but
  does not yet control ingestion behavior.
- Comprehensive security boundary testing is incomplete.
- Local Metrics Server has certificate validation issues.
- Credential-pattern scans are not a comprehensive
  security audit.

## Cloud Resource Status

GCP infrastructure was provisioned and tested,
then destroyed to prevent unnecessary credit usage.

The manually created Cloud Build service account
and source staging bucket were also removed.

Cloud runtime evidence is retained in evidence/.
No active RetailCo cloud deployment is claimed.

## Submission Status

Substantial implementation with verified local CI/CD,
Kubernetes resilience, cloud infrastructure and
security integration.

Outstanding requirements are explicitly documented.
Full milestone compliance is not claimed.

Previous milestone history is preserved in Git.

## Evidence Limitations

The original standalone GKE health and readiness
check files were empty and excluded from submission.

Other captured GKE deployment, application logs,
autoscaling and self-healing evidence is retained.

Selected cloud identifiers were redacted, and
UTF-16 evidence files were normalized to UTF-8.
