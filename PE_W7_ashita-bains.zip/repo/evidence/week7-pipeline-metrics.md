# Week 7 Final Pipeline Metrics

Scope: Observed end-to-end local CI/CD executions.

Total observed pipeline runs: 9
Successful pipeline runs: 7
Intentionally rejected pipeline runs: 2

Pipeline success rate: 77.78 percent (7/9).

Of the two rejected runs:
- One failed the unit test quality gate before deployment.
- One failed a simulated development health gate,
  triggering successful automatic rollback.

Both intentional failure tests achieved their
expected resilience outcomes.

Eight pipeline runs reached deployment.
Seven completed successfully.
Deployment-reaching pipeline success rate: 87.50 percent.

Separate manual Helm resilience tests are not included
in these end-to-end pipeline metrics.

The overall deployment reliability target cannot
be established from this limited local sample.

Remote GitOps and automated GKE deployment remain
incomplete. These are local pipeline metrics,
not cloud deployment reliability metrics.
