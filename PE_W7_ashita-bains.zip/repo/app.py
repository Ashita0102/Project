import urllib.request
import json
import base64
import os
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from ingest import run_ingestion

PORT = int(os.getenv("PORT", "8080"))
INPUT = os.getenv("INPUT_CSV", "/app/data/retailco_staging.csv")
OUTPUT = os.getenv("OUTPUT_CSV", "/tmp/retailco_output.csv")

ready = threading.Event()


def load_cloud_config():
    project = os.getenv("GCP_PROJECT_ID")
    secret_name = os.getenv("SECRET_NAME")

    if not project and not secret_name:
        print("Local configuration mode", flush=True)
        return

    if not project or not secret_name:
        raise RuntimeError("Incomplete cloud configuration")

    request = urllib.request.Request(
        "http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/default/token",
        headers={"Metadata-Flavor": "Google"}
    )

    with urllib.request.urlopen(request, timeout=30) as response:
        token = json.load(response)["access_token"]

    url = (
        f"https://secretmanager.googleapis.com/v1/projects/"
        f"{project}/secrets/{secret_name}/versions/latest:access"
    )

    request = urllib.request.Request(
        url,
        headers={"Authorization": "Bearer " + token}
    )

    with urllib.request.urlopen(request, timeout=30) as response:
        result = json.load(response)

    config = base64.b64decode(result["payload"]["data"])

    if not config:
        raise RuntimeError("Empty cloud configuration")

    print("Secret Manager configuration loaded successfully", flush=True)
    return config



def ingest_data():
    try:
        load_cloud_config()
        run_ingestion(INPUT, OUTPUT)
        ready.set()
        print("Ingestion completed successfully", flush=True)
    except Exception as error:
        print(f"Ingestion failed: {error}", flush=True)


class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == "/health":
            status = 200
            message = b"healthy"
        elif self.path == "/ready":
            status = 200 if ready.is_set() else 503
            message = b"ready" if ready.is_set() else b"not ready"
        else:
            status = 404
            message = b"not found"

        self.send_response(status)
        self.send_header("Content-Type", "text/plain")
        self.end_headers()
        self.wfile.write(message)


if __name__ == "__main__":
    threading.Thread(target=ingest_data, daemon=True).start()
    server = ThreadingHTTPServer(("0.0.0.0", PORT), Handler)
    print(f"Health service running on port {PORT}", flush=True)
    server.serve_forever()
