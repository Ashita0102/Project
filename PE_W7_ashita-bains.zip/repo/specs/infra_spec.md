﻿# Infrastructure Specification — Week 5

## 1. Objective
Define the base Google Cloud Platform infrastructure using Terraform.

## 2. Requirements
- Store Terraform configuration in the repository's terraform/ directory.
- Declare the Google Cloud provider and required variables.
- Keep project ID, region, and other environment-specific settings configurable.
- Avoid hardcoding credentials, service-account keys, or secrets.
- Define only the infrastructure required by the capstone and Week 5 brief.
- Include outputs for relevant provisioned resources.
- Document prerequisites and execution commands in README.md.

## 3. Validation
- terraform fmt completes without formatting errors.
- terraform init completes successfully.
- terraform validate succeeds.
- terraform plan is reviewed before provisioning.
- Apply, destroy, and reapply are tested where GCP permissions and quota permit.
- Validation results and any environmental limitations are recorded honestly.

## 4. Safety
- Do not provision billable resources without reviewing the plan.
- Do not commit Terraform state files, credentials, or secret values.
- Document any required APIs, IAM permissions, and project configuration.

## 5. Implementation Constraint
The exact resources must be selected according to the capstone application and Week 5 brief. No cloud resource is considered successfully provisioned until its result is verified.
