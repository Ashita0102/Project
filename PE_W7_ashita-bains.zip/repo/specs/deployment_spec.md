﻿# Week 6 Deployment Specification

## Project
Quantiphi Platform Engineer Capstone - Week 6
RetailCo Data Ingestion Application

## Objective
Deploy the existing RetailCo application on Kubernetes
using Helm, with automatic recovery, health monitoring,
resource management, and horizontal autoscaling.

## Existing Components
- Python ingestion application: ingest.py
- Dockerfile
- RetailCo staging dataset
- Terraform infrastructure configuration
- Week 5 Git history and documentation

## Target Environment
Production target: Google Kubernetes Engine (GKE)
Local testing: Minikube

## Kubernetes Resources
The Helm chart will manage:
- Deployment
- Service
- ConfigMap
- Secret references
- Ingress
- HorizontalPodAutoscaler

## Application Design
Preserve the existing RetailCo ingestion workflow.

If ingestion is a one-time batch process, introduce a
lightweight HTTP service for the continuous Deployment
workload without removing the existing ingestion script.

## Health Checks
Readiness endpoint: /ready
Liveness endpoint: /health
Application port: 8080

Readiness probe:
- Initial delay: 5 seconds
- Period: 10 seconds

Liveness probe:
- Initial delay: 15 seconds
- Period: 20 seconds

## Resource Management
CPU request: 100m
CPU limit: 500m
Memory request: 128Mi
Memory limit: 512Mi

## Autoscaling
Minimum replicas: 2
Maximum replicas: 5
Target CPU utilization: 60%

Metrics Server is required for CPU-based HPA.

## Self-Healing
Kubernetes Deployment will maintain the desired
replica count.

Deleting a pod should trigger automatic replacement.

Health probes will detect unhealthy containers.

## Configuration and Security
Use ConfigMaps for non-sensitive settings.
Use Kubernetes Secrets for sensitive values.
Do not commit credentials to Git.

## Deployment Strategy
1. Build and validate the Docker image.
2. Create and validate the Helm chart.
3. Deploy locally using Minikube.
4. Verify application health.
5. Demonstrate pod recovery.
6. Demonstrate HPA scaling under load.
7. Deploy to GKE when approved access is available.
8. Capture deployment evidence.

## Rollback
Use Helm release history and helm rollback.

## Evidence
Store deployment outputs and screenshots in evidence/.

Required demonstrations:
- Helm deployment
- Healthy Kubernetes pods
- Self-healing
- Horizontal autoscaling
- GKE deployment for final compliance

## Acceptance Criteria
- Helm chart renders valid Kubernetes manifests.
- Application deploys successfully.
- Readiness and liveness probes are functional.
- Resource requests and limits are configured.
- Kubernetes replaces failed pods.
- HPA scales workloads under sustained CPU load.
- Runbook documents deployment and recovery.
- Evidence is collected.
- GKE deployment is verified when access is available.

## Status
Specification completed.
Implementation not yet started.
