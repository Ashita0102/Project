\# Week 7 — RetailCo Automated Delivery Pipeline Specification



\## 1. Objective



Build a reproducible, automated delivery pipeline for the RetailCo containerized application, with automated testing, image building, Kubernetes deployment, GitOps configuration, controlled promotion, and rollback.



\## 2. Pipeline Requirements



The pipeline must:



1\. Trigger automatically when changes are committed to the configured repository branch.

2\. Run application validation and automated tests before building or deploying.

3\. Block deployment if a required test fails.

4\. Build a versioned Docker image using the Git commit identifier.

5\. Publish the image to an approved container registry when cloud access is available.

6\. Update the declared deployment configuration through a version-controlled GitOps workflow.

7\. Deploy to the approved GKE environment without manual deployment commands.

8\. Verify deployment health and readiness.

9\. Prevent promotion when validation or deployment health checks fail.

10\. Support a documented, reproducible one-step rollback to the previous known-good release.



\## 3. Repository Structure



\- `specs/` — specifications and acceptance criteria

\- `app/` — application source and automated tests

\- `pipeline/` — CI/CD pipeline configuration and supporting scripts

\- `gitops/` — version-controlled deployment declarations

\- `chart/` — Helm deployment chart

\- `evidence/` — execution logs, test results and rollback evidence



\## 4. Acceptance Criteria



\- Automated tests pass for valid application changes.

\- A deliberately failing test blocks the pipeline.

\- A successful pipeline builds an image with a traceable version.

\- GitOps declarations identify the intended application image and version.

\- The deployment reaches its required healthy replica count.

\- A seeded faulty release can be rolled back in one documented operation.

\- Deployment success rate is measured and reaches at least 85%.

\- Logs and evidence demonstrate the results of actual pipeline runs.



\## 5. Environments and Constraints



Local development uses Docker Desktop Kubernetes.



The required GKE deployment, cloud registry integration, cloud credentials and cloud-based delivery validation remain pending until authorized company GCP access is available.



Local Kubernetes results must not be presented as GKE results.



\## 6. Security Requirements



\- No service-account keys, tokens or passwords committed to Git.

\- CI/CD permissions follow least-privilege principles.

\- Secrets are provided through approved secure mechanisms.

\- Production promotion requires the configured quality and health gates.



\## 7. Evidence Requirements



Record the actual test results, pipeline executions, image identifiers, deployment health checks, rollback results and measured delivery success rate.



Do not mark unexecuted tests or unavailable cloud integrations as passed.

