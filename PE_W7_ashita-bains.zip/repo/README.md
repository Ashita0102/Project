# RetailCo Platform Engineering Capstone

## Overview

RetailCo is a containerized CSV ingestion application
with Kubernetes deployment, CI/CD automation,
infrastructure as code, and cloud security integration.

This repository extends the Week 5 and Week 6 work
with Week 7 and Week 8 implementations.

## Architecture

Git commit
  -> Automated unit tests
  -> Committed-source Docker build
  -> Commit-tagged image
  -> Development deployment
  -> Development health gate
  -> Staging promotion
  -> Staging health gate

Failed tests block deployment. Failed Helm upgrades
trigger rollback. A separate health-gate failure
also triggers restoration of the previous release.

## Repository Structure

- app.py: Application and HTTP health endpoints.
- ingest.py: RetailCo CSV ingestion logic.
- app/tests/: Automated unit tests.
- fixtures/: Synthetic sample dataset.
- Dockerfile: Application container definition.
- chart/: Kubernetes Helm chart.
- pipeline/: CI/CD scripts and Git hook.
- gitops/: Environment-specific Helm configurations.
- terraform/: GCP infrastructure definitions.
- specs/: Implementation specifications.
- evidence/: Execution and verification records.
- STATUS.md: Current milestone status and limitations.
- DECISIONS.md: Engineering decisions and rationale.

## Prerequisites

- Python 3.10 with pandas
- Git
- Docker Desktop with Kubernetes enabled
- kubectl
- Helm
- Terraform and Google Cloud CLI for cloud operations

## Run Unit Tests

```powershell
python -m pip install "pandas>=2.0,<3.0"
python -m unittest discover -s app/tests -p "test_*.py" -v
```

## Local CI

Run from the repository root:

```powershell
python pipeline/local_ci.py
```

The CI script extracts committed application source,
runs automated tests, and builds a Docker image.
The image includes the full Git commit SHA as metadata.

## Initial Local Deployment

The CD pipeline requires existing Helm releases.
For a new local cluster, first run local CI, then:

```powershell
kubectl --context docker-desktop create namespace retailco-staging

helm upgrade --install retailco ./chart --kube-context docker-desktop -n default -f gitops/values-dev.yaml --set image.repository=retailco-local-ci --set image.tag=latest --set image.pullPolicy=Never --wait --timeout 180s

helm upgrade --install retailco-staging ./chart --kube-context docker-desktop -n retailco-staging -f gitops/values-staging.yaml --set image.repository=retailco-local-ci --set image.tag=latest --set image.pullPolicy=Never --wait --timeout 180s
```

Skip namespace creation if it already exists.

## Enable Commit-Triggered CI/CD

```powershell
git config core.hooksPath pipeline/hooks
```

Subsequent Git commits trigger the local CI/CD pipeline.

Manual pipeline execution:

```powershell
python pipeline/local_cd.py
```

The post-commit hook cannot undo a Git commit.
A failed quality gate prevents deployment.

## Deployment Verification

```powershell
python pipeline/verify_deployment.py default retailco

python pipeline/verify_deployment.py retailco-staging retailco-staging
```

Both environments must pass their health gates.

## Week 7 Implementation

- Automated unit testing and Docker builds.
- Commit-triggered local CI/CD.
- Commit SHA image tagging and metadata verification.
- Development and staging environment promotion.
- Failed-build prevention.
- Helm rollback after a failed upgrade.
- Automatic development rollback after a simulated
  post-deployment health-gate failure.
- Google Cloud Build and Artifact Registry publishing.

Remote GitOps reconciliation and automated GKE
deployment have not been completed.

## Week 8 Implementation

Terraform defines the following infrastructure:

- Custom VPC and subnet.
- Private GKE nodes.
- Restricted control-plane network access.
- Cloud Router and Cloud NAT.
- Artifact Registry.
- Dedicated node service account.
- Scoped IAM permissions.
- Workload Identity.
- Secret Manager integration.

GKE deployment, autoscaling, self-healing and
Secret Manager configuration retrieval were tested.

The application retrieves configuration through
Workload Identity without a service-account key.
The retrieved configuration is validated, but is
not yet used to control ingestion behavior.

## Terraform Validation

```powershell
terraform -chdir=terraform init
terraform -chdir=terraform validate
```

Cloud provisioning requires an authorized project,
billing approval, enabled APIs, and appropriate IAM.

Review all Terraform variables and plans before
applying infrastructure changes.

Cloud Build also requires its dedicated service
account and source staging bucket.

## Cloud Resource Status

Cloud infrastructure was provisioned and tested.
Terraform-managed resources were subsequently
destroyed to control cloud costs.

The manually created Cloud Build service account
and source staging bucket were also removed.

Historical evidence is retained under evidence/.

Do not recreate cloud resources without authorization.

## Security

- Synthetic data is used for application builds.
- Credentials and Terraform state must not be committed.
- Cloud project configuration is parameterized.
- Services use internal ClusterIP networking.
- Secret values are not printed in application logs.
- Sensitive identifiers in selected evidence were redacted.

## Known Limitations

- Remote GitOps reconciliation is incomplete.
- Automated GKE deployment and promotion are incomplete.
- Independent staging rollback testing is pending.
- The overall 85 percent deployment reliability
  target has not been established.
- Local Metrics Server has certificate validation issues.
- Helm configuration is not built from an isolated snapshot.
- Container dependencies are not fully pinned.
- Fresh-clone setup instructions require independent testing.
- Cloud infrastructure is no longer running.

See STATUS.md and DECISIONS.md for additional details.
