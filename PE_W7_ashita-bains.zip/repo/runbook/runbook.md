﻿# RetailCo Week 6 Operations Runbook

## Application
RetailCo CSV ingestion service with HTTP health endpoints.

## Build
docker build -t retailco-week6:latest .

## Local Docker validation
docker run -d --name retailco-week6-test -p 8080:8080 retailco-week6:latest
curl.exe http://localhost:8080/health
curl.exe http://localhost:8080/ready

## Helm validation
helm lint ./chart
helm template retailco ./chart

## Kubernetes deployment
helm upgrade --install retailco ./chart
kubectl get deployments,pods,services,hpa

## Troubleshooting
kubectl describe pods
kubectl logs deployment/retailco

## Self-healing verification
Record the original pod names.
Delete one application pod using kubectl.
Observe whether the Deployment creates a replacement.
Capture before-and-after evidence.

## Autoscaling verification
Confirm Metrics Server is healthy.
Generate authorized application load.
Observe HPA CPU metrics and replica changes.
Capture scaling evidence.

## Current limitation
Docker Desktop Metrics Server cannot scrape kubelet metrics
because of an x509 certificate validation error.
HPA scaling has not been demonstrated.

## GKE
GKE deployment requires authorized project and cluster access.
Local Docker Desktop results do not establish GKE deployment.
