
import unittest
import pandas as pd

from ingest import (
    EXPECTED_COLUMNS,
    validate_columns,
    normalize_dates,
    read_source,
)


class TestRetailCoIngestion(unittest.TestCase):

    def test_valid_columns(self):
        df = pd.DataFrame(columns=EXPECTED_COLUMNS)
        validate_columns(df)

    def test_missing_columns_rejected(self):
        df = pd.DataFrame({"transaction_id": [1]})

        with self.assertRaises(ValueError):
            validate_columns(df)

    def test_invalid_dates_rejected(self):
        df = pd.DataFrame({
            "transaction_date": ["not-a-date"]
        })

        with self.assertRaises(ValueError):
            normalize_dates(df)

    def test_missing_input_file_rejected(self):
        with self.assertRaises(FileNotFoundError):
            read_source("nonexistent_retailco_test_file.csv")


if __name__ == "__main__":
    unittest.main()
