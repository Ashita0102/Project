resource "google_artifact_registry_repository" "retailco" {
  project       = var.project_id
  location      = var.region
  repository_id = "retailco-images"
  description   = "RetailCo container images"
  format        = "DOCKER"
}
