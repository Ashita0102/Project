resource "google_container_cluster" "retailco" {
  name                     = "retailco-gke"
  project                  = var.project_id
  location                 = "${var.region}-a"
  remove_default_node_pool = true
  initial_node_count       = 1
  deletion_protection      = true

  network    = google_compute_network.retailco.id
  subnetwork = google_compute_subnetwork.retailco.id

  ip_allocation_policy {
    cluster_secondary_range_name  = "retailco-pods"
    services_secondary_range_name = "retailco-services"
  }

  private_cluster_config {
    enable_private_nodes    = true
    enable_private_endpoint = false
    master_ipv4_cidr_block  = "172.16.0.0/28"
  }

  master_authorized_networks_config {
    cidr_blocks {
      cidr_block   = var.admin_cidr
      display_name = "Authorized administrator"
    }
  }

  release_channel {
    channel = "REGULAR"
  }

  workload_identity_config {
    workload_pool = "${var.project_id}.svc.id.goog"
  }
}

resource "google_container_node_pool" "retailco" {
  depends_on = [
    google_project_iam_member.gke_node_role,
    google_artifact_registry_repository_iam_member.gke_reader,
    google_compute_router_nat.retailco
  ]

  name       = "retailco-node-pool"
  project    = var.project_id
  location   = google_container_cluster.retailco.location
  cluster    = google_container_cluster.retailco.name
  node_count = 1

  autoscaling {
    min_node_count = 1
    max_node_count = 2
  }

  management {
    auto_repair  = true
    auto_upgrade = true
  }

  node_config {
    service_account = google_service_account.gke_nodes.email
    oauth_scopes    = ["https://www.googleapis.com/auth/cloud-platform"]
    machine_type    = "e2-standard-2"
    disk_size_gb    = 30
    disk_type       = "pd-standard"

    workload_metadata_config {
      mode = "GKE_METADATA"
    }
  }
}





