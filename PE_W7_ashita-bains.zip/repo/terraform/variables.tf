
variable "project_id" {
  description = "Google Cloud project ID"
  type        = string
}

variable "region" {
  description = "Google Cloud region"
  type        = string
  default     = "asia-south1"
}

variable "admin_cidr" {
  description = "Authorized administrator public IPv4 CIDR"
  type        = string
}
