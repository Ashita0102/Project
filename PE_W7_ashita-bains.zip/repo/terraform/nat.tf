resource "google_compute_router" "retailco" {
  project = var.project_id
  name    = "retailco-router"
  region  = var.region
  network = google_compute_network.retailco.id
}

resource "google_compute_router_nat" "retailco" {
  project                            = var.project_id
  name                               = "retailco-nat"
  router                             = google_compute_router.retailco.name
  region                             = var.region
  nat_ip_allocate_option             = "AUTO_ONLY"
  source_subnetwork_ip_ranges_to_nat = "ALL_SUBNETWORKS_ALL_IP_RANGES"
}
