resource "google_compute_network" "retailco" {
  project                 = var.project_id
  name                    = "retailco-vpc"
  auto_create_subnetworks = false
}

resource "google_compute_subnetwork" "retailco" {
  project                  = var.project_id
  name                     = "retailco-subnet"
  region                   = var.region
  network                  = google_compute_network.retailco.id
  ip_cidr_range            = "10.10.0.0/20"
  private_ip_google_access = true

  secondary_ip_range {
    range_name    = "retailco-pods"
    ip_cidr_range = "10.20.0.0/16"
  }

  secondary_ip_range {
    range_name    = "retailco-services"
    ip_cidr_range = "10.30.0.0/20"
  }
}
