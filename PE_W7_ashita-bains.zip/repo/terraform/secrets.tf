resource "google_secret_manager_secret" "retailco" {
  project   = var.project_id
  secret_id = "retailco-app-config"

  replication {
    auto {}
  }

  labels = {
    application = "retailco"
    environment = "dev"
  }
}

resource "google_secret_manager_secret_iam_member" "retailco_accessor" {
  depends_on = [google_container_cluster.retailco]

  project   = var.project_id
  secret_id = google_secret_manager_secret.retailco.secret_id
  role      = "roles/secretmanager.secretAccessor"
  member    = "principal://iam.googleapis.com/projects/${data.google_project.current.number}/locations/global/workloadIdentityPools/${var.project_id}.svc.id.goog/subject/ns/retailco/sa/retailco-app"
}

data "google_project" "current" {
  project_id = var.project_id
}

