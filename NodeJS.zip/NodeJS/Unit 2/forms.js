const express=require("express")
const app=express()
app.get("/",(req,res)=>{
    res.send(`
        <h2>Student Registration Form</h2>
        <form action="/submit" method="GET">
        NAME :
        <input type="text" name="name" placeholder="Enter your name"><br><br>

        AGE :
        <input type="number" name="age"><br><br>

        <button type="submit">SUBMIT</button>
        </form>
        `)
});

app.get("/submit",(req,res)=>
{
    const name=req.query.name;
    const age=req.query.age;

    res.send(`Name : ${name} <br> Age : ${age}`);
});
app.listen(3000,()=>{
    console.log("Server started");
});