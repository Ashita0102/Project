const http=require("http");
const server=http.createServer((req,res)=>
{
    const student=
    {
        name:"Ashita",
        age:20
    };
    res.setHeader("Content-type","application/json");
    res.end(JSON.stringify(student));
});
server.listen(3000);