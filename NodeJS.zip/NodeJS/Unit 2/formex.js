const express=require("express")
const path=require("path")
const app=express()
const PORT=3000;

//Middleware to parse data
app.use(express.urlencoded({extended:true}));

//display the form
app.get("/",(req,res)=>
{
    res.sendFile(path.join(__dirname,"formex.html"))
});

//handle login form submission
app.post("/login",(req,res)=>
{
    const {username,password}=req.body;

    //add the credentials
    const correctUsername="admin";
    const correctPassword="12345";
    if(username===correctUsername && password===correctPassword)
    {
        res.send(`
            <h2>Login Successful</h2>
            `)
    }
    else{
        res.send(`
            <h2>Login Fail</h2>
            <h2>Invalid username and Password</h2>
            <a href="/">Try login again</a>
            `)
    }
});
app.listen(PORT);