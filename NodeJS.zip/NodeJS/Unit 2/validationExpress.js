const express = require("express"); 
const {body, validationResult} = require("express-validator");

const app= express(); 

app.use(express.urlencoded({extended:true})); 

//Home Page 
app.get("/", (req, res) =>
{
    res.send(`
        <h2>Student Registration Form</h2>

        <form action="/validatedata" method="POST">

        Full Name: 
        <input type="text" name="fullname"><br><br>

        Email:
        <input type="email" name="email"><br><br>

        Password:
        <input type="password" name="password"><br><br>

        Username: 
        <input type="text" name="username"><br><br>

        Age: 
        <input type="number" name="age"><br><br>

        <input type="submit" value="Register">

        </form>
        `);
});

//validation 
app.post(
    "/validatedata", 
    [
        //full name 
        body("fullname")
        .trim()
        .notEmpty()
        .withMessage("Full name is required")
        .isLength({ min: 3})
        .withMessage("Name should contain at least 3 characters")
        .withMessage("Only alphabets and spaces are allowed"),


        //email 
        body("email")
        .trim()
        .isEmail()
        .withMessage("Enter a valid email")
        .normalizeEmail(), 

        //password
        body("password")
        .isLength({min :8})
        .withMessage("Password must contain 8 characters")
        .matches(/[A-Z]/)
        .withMessage("Password should contain atleast one uppercase letter")
        .matches(/[a-z]/)
        .withMessage("Password should contain atleast one lowercase letter")
        .matches(/[0-9]/)
        .withMessage("Password should contain atleast one number")
        .matches(/[!@#$%^&*]/)
        .withMessage("Password should contain special character"), 

        //username 
        body("username")
        .trim()
        .isLength({min:5, max:15})
        .withMessage("username should be between 5 to 15 char")
        .isAlphanumeric()
        .withMessage("Username should contain letter and number"),

        //age 
        body("age")
        .isInt({ min:18, max: 70})
        .withMessage("Age should be between 18 to 70")
    ], 

    (req, res) =>
    {
        const errors = validationResult(req)

        if(!errors.isEmpty())
        {
            return res.status(400).json({
                success: false, 
                totalErrors: errors.array().length, 
                errors: errors.array()
            });
        }

        res.send(`
            <h2>Registration Successful </h2>
            
            <h3>Submitted the form </h3>
            `); 
    }
); 

//start the server 
app.listen(3000);