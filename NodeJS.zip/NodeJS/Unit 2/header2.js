const http=require("http");
const server=http.createServer((req,res)=>
{
    res.setHeader("Content-type","text/plain");
    res.end("Hello This is node page");
});

server.listen(3000);