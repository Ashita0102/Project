const http=require("http");
const server=http.createServer((req,res)=>
{
    res.write("<h1>Welcome</h1>");
    res.write("<p>Welcome to node page</p>");
    res.end();
});


server.listen(3000,()=>
{
    console.log("Server is running on port 3000");
});