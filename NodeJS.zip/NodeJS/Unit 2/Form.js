const express=require("express");
const path=require("path");
const app=express()
app.use(express.urlencoded({extended:true}));
app.get("/",(req,res)=>
{
    res.sendFile(path.join(__dirname,"Form.html"));
});

app.post("/",(req,res)=>
{
    const {name,uid,date,leave,reason}=req.body;
    res.send(`
        <p>Name: ${name}</p>
        <p>UId: ${uid}</p>
        <p>Date: ${date}</p>
        <p>leave: ${leave}</p>
        <p>Reason: ${reason}</p>
        `)
})
app.listen(3000);