const fs=require('fs')
fs.unlink("delete.txt",(err)=>
{
    if(err)
    {
        console.log(err)
        return;
    }
    console.log("file is deleted");
})