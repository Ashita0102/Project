//create an online application form for your college event
//name.email,contact number,dob
const express=require("express")
const app=express()
app.get("/",(req,res)=>{
    res.send(`
        <h1>EVENT REGISTRATION FORM</h1>
        <form action="/submit" method="GET">
        NAME :
        <input type="text" name="name" placeholder="Enter your name"><br><br>

        EMAIL :
        <input type="email" name="email"><br><br>

        CONTACT:
        <input type="tel" name="contact"><br><br>

        DOB:
        <input type="date" name="dob"><br><br>

        <button type="submit">SUBMIT</button>
        </form>
        `)
});

app.get("/submit",(req,res)=>
{
    const name=req.query.name;
    const email=req.query.email;
    const contact=req.query.contact;
    const dob=req.query.dob;

    res.send(`Name : ${name} <br> Email : ${email} <br> Contact : ${contact}<br> Dob : ${dob}`);
});
app.listen(3000,()=>{
    console.log("Server started");
});