//routing
const http=require('http');
const server=http.createServer((req,res)=>
{
    if(req.url === "/")       // / this slash means home page
    {
        res.end("Hello this is home page"); 
    }
    else if(req.url === "/about")
    {
        res.end("This is about page");
    }
    else
    {
        res.end("404 page not found"); //status code 404 that file is not there
    }
});
server.listen(3000);

//create routing for online electronic product purchase platform
//home -this is home page
//about -this is about page
//product details -it should display name and price of product with the help of HTML tags
//contact -it shows the contact number
//if there is some different route,it should display 404