//create mulitipl eroute for ecommerce website
//home should display welcome message
//product details - name and price
//booking details- message order booked
//all content in html
const express =require("express");
const app=express()
app.get("/",(req,res)=>
{
    res.send("<h1>Welcome the website </h1>");
});

app.get("/ProductDetails",(req,res)=>
{
    res.send("Shoes ,2000");
});

app.get("/BookingDetails",(req,res)=>
{
    res.send("Order booked");
});

app.listen(3000);