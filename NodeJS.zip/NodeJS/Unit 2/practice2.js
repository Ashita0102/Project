//form -2 input types
//user will type first and second number
//on the click of button show the largest number on server
const express=require("express")
const path=require("path")
const app=express()
app.use(express.urlencoded({ extended: true }));
app.get("/",(req,res)=>
{
    res.sendFile(path.join(__dirname,"practice2.html"))
})

app.post("/abc",(req,res)=>
{
    const num1=Number(req.body.num1)
    const num2=Number(req.body.num2)
    if (num1 > num2)
        res.send("Largest Number is: " + num1);
    else
        res.send("Largest Number is: " + num2);
})
app.listen(3000);