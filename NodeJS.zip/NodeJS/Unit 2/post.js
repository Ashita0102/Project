// get is used to receive the data
//post to send data to server