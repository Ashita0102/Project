
const express=require("express");
const path=require("path")

const app=express()
const PORT=3000;
//Display the registration form
app.get("/",(req,res)=>{
    res.sendFile(path.join(__dirname,"registrationForm.html"));
});

//receive the GET request from the form
app.get("/register",(req,res)=>
{
    const data=req.query;
    //req.query.name is now written as data.name
    res.send(`
        <h2>Registration successfull </h2>
        <h3>Below are the details, Kindly check</h3>
        Name: ${data.fullname}<br><br>
        Password: ${data.password}<br><br>
        Email: ${data.email}<br><br>
        Age: ${data.age}<br><br>
        Contact No: ${data.contact}<br><br>
        Website: ${data.website}<br><br>
        Date of Birth: ${data.dob}<br><br>
        Time: ${data.time}<br><br>
        Appointment: ${data.appointment}<br><br>
        Month: ${data.month}<br><br>
        Week: ${data.week}<br><br>
        Favourite Colour: ${data.color}<br><br>
        Programming Skill: ${data.skill}<br><br>
        Gender: ${data.Gender}<br><br>
        Hobbies: ${data.Hobbies}<br><br>
        Resume: ${data.resume}<br><br>
        Course: ${data.course}<br><br>
        Department: ${data.Department}<br><br>
        Address: ${data.Address}<br><br>
        `)
});
app.listen(PORT,()=>
{
    console.log("Server running");
});