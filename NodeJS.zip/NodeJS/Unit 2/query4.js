const http=require("http");
const url=require("url");
http.createServer((req,res)=>
{
    const query=url.parse(req.url,true).query;
    
    if(query.username === "admin" && query.password === "1234")
    {
        res.end("Login successfull");
    }
    else{
        res.end("Invalid username or password");
    }

}).listen(3000);