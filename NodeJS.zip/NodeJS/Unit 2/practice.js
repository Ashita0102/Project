//write an express js application that displays an HTML form
//to accept a student's .When the user submits the form
//the name of student should be saved in file named student.txt using node.js
//and fs module to display the name.
const express = require("express");
const fs = require("fs");

const app = express();

app.use(express.urlencoded({ extended: true }));

app.get("/", (req, res) => {
    res.send(`
        <html>
        <body>
            <h2>Student Form</h2>
            <form action="/submit" method="POST">
                Name: 
                <input type="text" name="studentName" required>
                <br><br>
                <button type="submit">Submit</button>
            </form>
        </body>
        </html>
    `);
});

app.post("/submit", (req, res) => {
    const name = req.body.studentName;

    fs.writeFile("student.txt", name, (err) => {
        if (err) {
            return res.send("Error saving file");
        }

        fs.readFile("student.txt", "utf8", (err, data) => {
            if (err) {
                return res.send("Error reading file");
            }

            res.send(`<h2>Student Name Saved Successfully!</h2>
                      <p>Name: ${data}</p>`);
        });
    });
});

app.listen(3000, () => {
    console.log("Server running at http://localhost:3000");
});