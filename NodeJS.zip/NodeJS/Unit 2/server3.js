const http=require("http");
const server=http.createServer((req,res)=>
{
    console.log("URL",req.url);  //details of url
    console.log("Method :",req.method);   //methods are used for CRUD operations

    //fetching data-GET method
    //filling a form-post method 
    //for deleting -delete
    //for update-update

    res.end("Request Information Printed");
});

server.listen(3000);