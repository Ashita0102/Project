
//create 2 routes,1 route will reflect the details
//where user is the student of university or not - set username as StudentUser
//if student is not the current student -it should dispaly not active
const express=require("express");
const app=express()
app.get("/student/:name",(req,res)=>
{
    res.send(
        "Name : "+req.params.name +
        " , Age : " +req.params.age
    );
});
app.get("/student")
app.listen(3000);
