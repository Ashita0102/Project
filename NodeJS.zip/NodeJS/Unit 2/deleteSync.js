const fs=require('fs')
try{
    fs.unlinkSync("delete.txt")
    console.log("File deleted successfully")
}
catch{
    console.log("error: ", err)
}