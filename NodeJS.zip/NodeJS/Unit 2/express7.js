const express = require("express")
const app=express()
app.get("/add",(req,res)=>
{
    let num1=Number(req.query.num1);
    let num2=Number(req.query.num2);

    let sum=num1+num2;
    res.send("SUM = "+sum);
});
app.listen(3000);