//request is given by the user and respond by server
//first import this core module
const http=require("http");

//create a server
const server=http.createServer((req,res)=>
{
    res.write("Hello this is node JS");
    res.end();
});

//start the server with listen with port number 
server.listen(3000,()=>
{
    console.log("Server is running on port 3000");
});


//to exit it on terminal press ctrl+c and it will stop the running server
// while the server is running...search localhost:3000