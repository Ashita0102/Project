const express=require("express")
const fs=require('fs')

const app=express()
const PORT=3000;

app.use(express.urlencoded({extended:true}))

app.get("/",(req,res)=>
{
    res.send(`
        <form action="/copy" method="post">
        Source:
        <input type="text" name="source"><br><br>
        Destination:
        <input type="text" name="des"><br><br>
        <button type="submit">COPY</button>
        </form>
        `)
});

app.post("/copy",(req,res)=>
{
    const{source,des}=req.body;
    fs.copyFile(source,des,(err)=>
{
    if(err)
    {
        return req.send(`<h3>${err.message}</h3>`);
    }
    res.send(`
        <h2>Success!!</h2>
        <p>Content copied successfully from <b>${source}</b> to <b>${des}</b> </p>
        `)
})
})
app.listen(PORT);