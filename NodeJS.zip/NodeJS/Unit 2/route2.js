const http=require('http');
const server=http.createServer((req,res)=>
{
    if(req.url === "/")       // / this slash means home page
    {
        res.end("<h1>Hello this is home page</h1>"); 
    }
    else if(req.url === "/about")
    {
        res.end("<h1>This is about page</h1>");
    }
    else if(req.url === "/ProductDetails")
    {
        res.end("<p>Shoes</>");
        res.end("<p>20,000</p>");
    }
    else if(res.url === "/contact")
    {
        res.end("xxxxxxxxxxxxx");
    }
    else{
        res.end("404 page not found"); 
    }
});
server.listen(3000);