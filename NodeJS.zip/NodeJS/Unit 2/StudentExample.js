const express=require("express")
const app=express()
const PORT=3000;
app.use(express.urlencoded({extended:true}));

//home page
app.get("/",(req,res)=>
{
    res.send(`
        <h1>Student Management System</h1>
        <h2>SearchStudent(GET)</h2>

        <form action="/search" method="GET">
        Roll no:
        <input type="number" name="roll">
        <button type="submit">Search</button>
        </form>

        <hr>

        <h2>Add student(POST)</h2>
        <form action="/add" method="POST">
        Name:
        <input type="text" name="name"><br><br>

        Roll no:
        <input type="number" name="roll"><br><br>

        Course:
        <input type="text" name="course"><br><br>

        <button type="submit">ADD STUDENT</button>
        </form>
        `);
});

//GET
app.get("/search",(req,res)=>
{
    const roll=req.query.roll;
    res.send(`
        <h2>Student Search</h2>
        You searched for roll no:<b>${roll}<b>
        `);
});

//POST
app.post("/add",(req,res)=>
{
    const {name,roll,course}=req.body;

    res.send(`
        <h2>Student Added Successfully<h2>
        Name:${name}<br>
        Roll No:${roll}<br>
        Course:${course}
        `);
});
app.listen(PORT,()=>
{
    console.log("Server is running");
});