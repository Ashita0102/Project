const express=require("express")
const path=require("path")

const app=express()
app.use(express.urlencoded({extended:true})); //middleware to work on complex data types
app.get("/",(req,res)=>
{
    res.sendFile(path.join(__dirname,"feedback.html"));
});

app.post("/feedback",(req,res)=>
{
    const {name, course, rating, comments}=req.body

    res.send(`
        <h2>Feedback Received</h2>
        <p>Name: ${name}</p>
        <p>Course: ${course}</p>
        <p>Rating: ${rating}</p>
        <p>Comments: ${comments}</p>
        `)
});
app.listen(3000);