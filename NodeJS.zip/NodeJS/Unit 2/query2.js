const http=require("http");
const url=require("url");
const server=http.createServer((req,res)=>
{
    const parseurl=url.parse(req.url,true);  //parse url
    //get the query
    //name and age are the query parameters
    const query =parseurl.query;
    res.writeHead(200,{"content-type":"text/plain"});
    res.write("Name : "+query.name + "\n");
    res.write("Age :"+ query.age);
    res.end();
});
server.listen(3000,()=>
{
    console.log("Server running at http://localhost:3000");
});