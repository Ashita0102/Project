//it is a metadata that tell what type of content we are using on webpage
const http=require("http");
const server=http.createServer((req,res)=>
{
    res.writeHead(200,
        {
            "Content-Type": "text/html"
        });
        res.end("<h1>Welcome to the node page</h1>");
});
server.listen(3000);