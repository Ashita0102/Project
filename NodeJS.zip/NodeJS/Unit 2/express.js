const express=require('express'); //import the module
const app=express()
app.get("/",(req,res)=>
{
    res.send("<h1>Hello Express</h1>");
})

app.listen(3000,()=>
{
    console.log("Server is running....");
});