const fs=require("fs")
const file1="data1.txt"
const file2="data2.txt"
const outFile="combine.txt"

fs.readFile(file1,'utf-8',(err,data1)=>
{
    if(err)
    {
        console.log(err);
    }
    fs.readFile(file2,'utf-8',(err,data2)=>
    {
        if(err)
        {
            console.log(err);
        }
        const combined=data1 + '\n' + data2
    fs.writeFile(outFile,combined,(err)=>
    {
        if(err)
        {
            console.log(err);
        }
        console.log("Combined successfully")
    })

    })
})