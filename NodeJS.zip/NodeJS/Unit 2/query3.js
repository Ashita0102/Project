const http=require("http");
const url=require("url");
http.createServer((req,res)=>
{
    const query=url.parse(req.url,true).query;
    const length=Number(query.length);  //typecasting 
    const width=Number(query.width);
    const area=length*width;
    res.end(`Area= ${area}`); //not a string so "" not used

}).listen(3000);