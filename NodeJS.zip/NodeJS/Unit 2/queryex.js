const http=require("http");
const url=require("url");
const server=http.createServer((req,res)=>
{
    const parseurl=url.parse(req.url,true);
    const query=parseurl.query;
    res.writeHead(200,{"content-type":"text/plain"});
    res.write("Emp Name: "+query.name+"\n");
    res.write("Salary: "+query.sal);
    res.end();

});
server.listen(3000);