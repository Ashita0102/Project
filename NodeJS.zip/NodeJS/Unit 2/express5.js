const express=require("express");
const app=express()
app.get("/student/:name/:age",(req,res)=>
{
    res.send(
        "Name : "+req.params.name +
        " , Age : " +req.params.age
    );
});
app.listen(3000);


