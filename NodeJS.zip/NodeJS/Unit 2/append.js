//create a file file1.txt and byb using express and html form appwnd the data of the file
//show a success message on the server
const express=require('express')
const fs=require('fs')
const app=express()
const PORT=3000;

app.use(express.urlencoded({extended:true}))

app.get("/",(req,res)=>
{
    res.send(`
        <form action="/append" method="post">
        File input:
        <input type="text" name="file"><br><br>
        <button type="submit">APPEND</button>
        </form>
        `)
});

app.post("/append",(req,res)=>
{
    const{file}=req.body;
    fs.appendFile('file2.txt',(err)=>
    {
        if(err)
        {
            return res.send(`
                <h3>${err.message}</h3>
                `)
        }
        res.send(`
            <p>Success</p>`)
    })
})
app.listen(PORT)
