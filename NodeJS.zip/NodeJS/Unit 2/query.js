//when searching on google...the search bar after ? whatever is written is query
//query is a kind of object

//import modules
const http =require("http");
const url=require("url");
const server=http.createServer((req,res)=>
{
    const data=url.parse(req.url,true);  //url details
    const name=data.query.name;
    res.end("Welcome "+ name);
});

server.listen(3000);   // write       localhost:3000/?name=Ashita      to see the name 