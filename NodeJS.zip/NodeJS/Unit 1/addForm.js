//create 3 inpurs with html form, and get the result of addition of these 3 on the server
const express=require('express')
const app=express()
const fs=require('fs')
app.use(express.urlencoded({extended:true}))
app.get("/",(req,res)=>
{
    res.send(`
    <form action="/" method='post'>
    <input type="number" name="num1"></input>
    <input type="number" name="num2"></input>
    <input type="number" name="num3"></input>
    <button type='submit'>ADD</button>
    </form>
        `)
})

app.post("/add",(req,res)=>
{
    const{num1,num2,num3}=req.body;
    fs.appendFile()
})