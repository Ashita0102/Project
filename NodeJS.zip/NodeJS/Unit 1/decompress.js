const fs=require('fs');
const zlib=require('zlib');

//read the compressed file
const readStream=fs.createReadStream('sample.txt.gz');

//create a writeable stream
const writeStream=fs.createWriteStream('test.txt');

//create gunzip transformation
const gunzip=zlib.createGunzip();

//pipe::read::decompression::write
readStream.pipe(gunzip).pipe(writeStream);
console.log("File is decompressed");
