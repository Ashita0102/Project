import {displayProduct,Result} from "./student3.js";
displayProduct("Car","Vehicle",1000000,"Black");
console.log(Result(1000000));