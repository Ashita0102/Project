export function displayStudent(name,age,course)
{
    console.log("Student Details");
    console.log("Name: ",name);
    console.log("Age: ",age);
    console.log("Course: ",course);
}

export function calculateGrades(marks)
{
    if(marks>=90)
        return "A+";
    else if(marks>=75)
        return "A";
    else if(marks>=40)
        return "C";
    else
        return "Fail";
}