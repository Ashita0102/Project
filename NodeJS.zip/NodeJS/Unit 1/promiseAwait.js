//example with async and await
function getData()
{
    return new Promise((resolve)=>
    {
        setTimeout(()=>
        {
            resolve("Data received");
        },3000)
    })
}

async function displayData() {
    console.log("Fetching data...");
    const result=await getData();
    console.log(result);
}
displayData();