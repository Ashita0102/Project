const fs=require('fs');
try{
    fs.appendFileSync('sample.txt','\nThis line is applied sync','utf-8');
    console.log("Data appended successfully");
}
catch(err)
{
    console.log("Error in appending",err);
}
console.log("Problem finished");