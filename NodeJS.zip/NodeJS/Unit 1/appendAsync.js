const fs = require('fs')
const content="\nThis is appending data";
fs.appendFile('sample.txt',content,'utf-8',(err)=>
{
    if(err)
    {
        console.log(err);
    }
    console.log("Data appended successfully");
});
console.log("Appending operation started...");