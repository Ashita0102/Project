export function displayProduct(name,category,price,colour)
{
    console.log("Product Details");
    console.log("Name: ",name);
    console.log("Category: ",category);
    console.log("Price: ",price);
    console.log("Colour: ",colour);
}
export function Result(price){
if(price>50000)
    return "High price";
else
    return "Low Price";
}