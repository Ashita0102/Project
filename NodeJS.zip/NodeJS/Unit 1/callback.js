//there we can use another function as a parameter or a argument in other function
//it works with asyncronous
//more flexible and easy to use
function greet(name,sayBye)
{
    console.log("Hello "+ name);
    sayBye();
}
function sayBye()
{
    console.log("Goodbye!!!");
}

greet("ABC",sayBye);
