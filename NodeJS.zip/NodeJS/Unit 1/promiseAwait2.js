function getData(){
    return new Promise((resolve,reject)=>
    {
        let success=true;
        //let success=false;
        if(success)
        {
            resolve("Promise is resolved successfully");
        }
        else
        {
            reject("Promise rejected");
        }
    });
}
async function displayData()
{
    console.log("Hello student....");
    const result=await getData();
    console.log(result);
}

displayData();