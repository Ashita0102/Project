console.log("Hello");
let age = 10;
let name = "Srajan";
console.log(name);
console.log(age);

let a = 10;
let b = 20;
console.log("Addition is: ",a+b);
console.log("Subtraction is: ",a-b);
console.log("Multiplication is: ",a*b);
console.log("division is: ",a/b);

let firstname = "ABC";
let city = "Delhi";
console.log("Name : ",firstname);
console.log("City : ",city);

//IF ELSE

let umar = 18;
if(umar>=18){
    console.log("Eligible to vote");
}else{
    console.log("Not Eligible to vote");
}


//for loop
for(let i=1;i<=5;i++){
    console.log(i);
}


