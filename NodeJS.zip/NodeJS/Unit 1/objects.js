// let student = {
//     name:"ABC",  //name is key and ABC is value
//     age:25,
//     city:"Delhi"
// };

// console.log(student);

// //access -1
// console.log(student.name);

// //access -2
// console.log(student["name"]);

//create an object with the name employee properties - empid , dept , salary,designation;

// let employees = {
//     empid:1,
//     dept : "Finance",
//     salary : 89000,
//     designation : "Manager"
// }
//console.log(employees);


//update the property
let student={
    name:"Ashita",
    age:20
};
student.age=21; //update age to 21;
console.log(student);

//add a property
student.city="Jal";
console.log(student);

