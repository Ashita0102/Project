const fs=require('fs');
fs.readFile('student.json','utf-8',(err,data)=>
{
    if(err)
    {
        console.log(err);
        return;
    }
    const student = JSON.parse(data);  //to convert data from one type to another
    console.log(student);
    console.log(student.name);
    console.log(student.age);
    console.log(student.course);
});

