const fs=require('fs');
//try catch not possible in async so we use callback error
try{
    const data=fs.readFileSync('sample.txt','utf-8');
    console.log(data);
}
catch(err)
{
    console.log("Error reading file: ",err);
}
console.log("Program finished!");
