//local modules - es(import) and common(require function) module
// this one is es way
export function add(a,b)
{
    return a+b;
}
export function subtract(a,b)
{
    return a-b;
}
export function multiply(a,b)
{
    return a*b;
}
export function divide(a,b)
{
    return a/b;
}