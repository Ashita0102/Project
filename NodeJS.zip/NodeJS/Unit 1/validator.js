//3rd party module used for validation like email format validation
import validator from "validator";
console.log(validator.isEmail("student@gmail.com"));
console.log(validator.isEmail("student123"));