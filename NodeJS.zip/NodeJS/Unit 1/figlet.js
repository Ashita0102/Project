//3rd party module to print data in big formats
import figlet from "figlet";
figlet(("NodeJS"),function(err,data)
{
    if(err)
    {
        console.log(err);
        return;
    }
    console.log(data);
})