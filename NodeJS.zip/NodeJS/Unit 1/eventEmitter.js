//events are some actions performed like if we hover the mouse and the colour change
//event emitter is displaying a particular action in terminal
//eventEmitetr is the class so object is made
var EventEmitter = require('events')
var obj = new EventEmitter();
obj.addListener('marketOpen',(msg) =>
{
    console.log(msg)
})
obj.emit('marketOpen','The market is open');