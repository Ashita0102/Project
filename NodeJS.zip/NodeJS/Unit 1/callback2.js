function product(name,size,price)
{
    console.log("Product name: ",name);
    console.log("Product size: ",size);
    price();
}
function price()
{
    console.log("Price: 20000");
}

product("Shoes",9,price);