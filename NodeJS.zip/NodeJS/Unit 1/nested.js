//nested objects
let student={
    name:"Ashita",
    address:{
        city:"hsp",
        state:"Punjab",
    }
};
console.log(student);
console.log(student.address.city);
console.log(student.address.state);
