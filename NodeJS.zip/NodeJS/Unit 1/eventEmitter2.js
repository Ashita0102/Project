var EventEmitter2 = require('events')
var obj = new EventEmitter2();
obj.addListener('day',(msg) =>  // other way for adding a event is on function
{
    console.log(msg)
})
obj.emit('day','Today is Monday');

//other method
obj.on('weather',(msg)=>
{
    console.log(msg);
})
obj.emit('weather','weather is cloudy');

console.log(obj.getMaxListeners()); // by default max value is 10

//if the same event has to be done repeatedly then use for loop
for(let i=0;i<9;i++)
{
    obj.addListener('weather',(msg)=>
    {
        console.log(msg);
    })
}
obj.emit('weather','weather is cloudy');

//once function which is for event that has to be done once
obj.once('college',(msg)=>
{
    console.log(msg);
})
obj.emit('college','Sunny');

var fun1=()=>
{
    console.log('Today is a good day');
}

var fun2=()=>
{
    console.log('Just another day');
}
obj.addListener('marketOpen',fun1);
obj.addListener('marketOpen',fun2);
obj.emit('marketOpen');

obj.removeListener('marketOpen',fun1); //one function
obj.emit('marketOpen');
