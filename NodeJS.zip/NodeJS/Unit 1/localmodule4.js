import{area} from "./localmodule3.js";
console.log("Area: ",area(34,25));