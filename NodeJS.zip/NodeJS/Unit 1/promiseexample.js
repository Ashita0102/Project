// write a program to check if the promise is resolved or reject is the 
// //student is part of a section..
//display the same message in terminal
console.log("Hello student");
const student=new Promise((resolve,reject)=>
{
    let success=true;
    //let success=false;
    if(success)
    {
        resolve("Student is part of class");
    }
    else
    {
        reject("Promise rejected");
    }
});

myPromise.then((message)=>
{
    console.log(message);
}). catch((error)=>
{
    console.log(error);
});

console.log("end");