const fs = require('fs');

try {
    const data = fs.readFileSync('abc2.json', 'utf8');
    const student = JSON.parse(data);

    console.log(student);
}
catch (err) {
    console.log(err);
}

console.log("File read");