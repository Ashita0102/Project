import { displayStudent,calculateGrades } from "./student.js";
displayStudent("Rahul",20,"B.Tech");
let grade=calculateGrades(82);
console.log("Grade: ",grade);

//display details of a product 
