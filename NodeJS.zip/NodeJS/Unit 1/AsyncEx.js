const fs=require('fs');
const content="Creating a content outline is one of the most important steps when writing. In this article, we'll go over what a content outline is and how to create one";
fs.writeFile('sample2.txt',content,'utf-8',(err)=>
{
    if(err)
    {
        console.log("Error in writing :",err);
    }
    console.log("File written successfully");
});
const data="\nCreating a content outline is one of the most important steps when writing. In this article, we'll go over what a content outline is and how to create one";
fs.appendFile('sample2.txt',data,'utf-8',(err)=>
{
    if(err)
    {
        console.log(err);
        }
    console.log("File Appended");
});
fs.readFile('sample2.txt','utf-8',(err)=>
{
    if(err)
    {
        console.log(err);
        return;
    }
    console.log(data);
});