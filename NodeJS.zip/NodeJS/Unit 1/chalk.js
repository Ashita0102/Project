import chalk from "chalk";
console.log(chalk.green("Welcome to NODE "));
console.log(chalk.blue("This is blue colour"));
console.log(chalk.red("Error"));