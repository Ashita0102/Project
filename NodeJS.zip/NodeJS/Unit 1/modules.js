//diving the code to optimize its usage
//some modules like core----fs,http,url, 3rd party---express,mongodb,figlet.....
//3 categories - core(already present in system)
//             - local or custom(user inbuilt)
//             - 3rd party(performing extra function that were not there after the js download)


// downlaod 3rd party modules like----nmp install chalk(for express)

// write module for es(import) and commonjs for required in package.json