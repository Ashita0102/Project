import localmodule5 from "./localmodule5.js";
console.log(localmodule5.add(20,2));
console.log(localmodule5.subtract(20,2));
console.log(localmodule5.multiply(20,2));
console.log(localmodule5.divide(20,2));