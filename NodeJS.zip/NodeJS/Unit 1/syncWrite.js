const fs=require('fs');
try{
    fs.writeFileSync('sample.txt','Hello ! This is sync writing','utf-8');
    console.log("File written successfully!");
} 
catch(err)
{
    console.log("Error loading file");
}
console.log("END");