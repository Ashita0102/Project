console.log("Order Placed");
const foodOrder=new Promise((resolve,reject)=>
{
    setTimeout(()=>
    {
        resolve("Pizza delivered");
    },3000);
});

foodOrder.then((message)=>
{
    console.log(message);
}).catch((error)=>
{
    console.log(error);
});
console.log("Please wait...");