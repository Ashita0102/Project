//asyncronous callback--- which is done first will execute first
//that do steps one  by one ---syncronous


// console.log("Start");
// setTimeout(()=>
// {
//     console.log("Task completed");
// },2000); // for the delay of time in milliseconds
// console.log("End");


function showMessage()
{
    console.log("Task completed");
}
setTimeout(showMessage,2000);