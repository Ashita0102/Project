import{add,subtract,multiply,divide} from "./localmodule.js";
console.log("Add: ",add(10,5));
console.log("Sub: ",subtract(10,5));
console.log("Mul: ",multiply(10,5));
console.log("Div: ",divide(10,5));