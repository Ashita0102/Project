//create a project named StudentManager
//initialize it using npm init
//create a student.json file containing:name,rollno,age
//create a local module greeting.js that displays: welcome message
//read student.json using the fs module
//display the details
