//example of promise without async/await
//await is going to give first preference to promise then rest will work
function getData()
{
    return new Promise((resolve)=>
    {
        setTimeout(()=>
        {
            resolve("Data is received");
        },3000)
    });
}

getData().then((result)=>
{
    console.log(result);
})