function getData()
{
    return new Promise((resolve,reject)=>
    {
        setTimeout(()=>
        {
            resolve("Pizza delivered");
        },3000);
    });
}
 async function foodOrder()
 {
    console.log("Getting order....");
    const result=await getData();
    console.log(result);
 }

 foodOrder();