const fs=require('fs');
const student={
    name:"Ashita",
    age:20,
    marks:95
};
try{
    fs.writeFileSync('abc1.json',JSON.stringify(student,null,2))
    console.log("JSON file created");
}
catch(err)
{
    console.log(err);
}