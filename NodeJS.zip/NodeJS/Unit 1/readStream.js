//stream is flow of data transfered in chunks
const fs=require('fs');
const readStream=fs.createReadStream('sample.txt','utf-8');
readStream.on('data',(chunk)=>
{
    console.log("RECEIVED CHUNKS: ");
    console.log(chunk);
});
readStream.on('end',()=>
{
    console.log("File reading compiled");
});
readStream.on('error',(err)=>
{
    console.log("error:",err);
});
