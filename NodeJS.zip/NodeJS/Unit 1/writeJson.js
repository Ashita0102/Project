const fs=require('fs');
const student={
    name:"Ashita",
    age:20,
    marks:95
};
fs.writeFile('abc.json',JSON.stringify(student,null,2),(err)=>  //earlier abc file was not created and directly written content
{
    if(err)                                            //without making a file we cannot read but we can write
    {                                                  //stringify is used to convert json to string
        console.log(err);
        return;
    }
    console.log("Json file created");
});