//it is an object that ensure the async process will take place
//3 states- resolve,reject,inprocess/pending
console.log("Start");
const myPromise=new Promise((resolve,reject)=>
{
    //let success=true;
    let success=false;
    if(success)
    {
        resolve("Promise is resolved successfully");
    }
    else
    {
        reject("Promise rejected");
    }
});

myPromise.then((message)=>
{
    console.log(message);
}). catch((error)=>
{
    console.log(error);
});

console.log("end");

