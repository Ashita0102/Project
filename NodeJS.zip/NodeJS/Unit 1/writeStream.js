const fs=require('fs');
const writeStream=fs.createWriteStream('output.txt');
writeStream.write("Hello students\n");
writeStream.write("Welcome to node JS\n");
writeStream.write("Stream are efficient\n");
writeStream.end();
writeStream.on('finish',()=>
{
    console.log("Writing completed");
})
writeStream.on('error',(err)=>
{
    console.log("Error",err);
})