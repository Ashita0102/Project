const express = require("express"); 
const app = express(); 

app.use(express.urlencoded({extended:true}))
app.use(express.json())

let orders = [];

app.get("/", (req, res) =>
{
    res.send(
        `
       <h2>Books Ordering From library</h2>
       <form action = "/orders" method="POST">

       Customer Name:
       <input type = "text" name="customer" required>
       <br><br>

       Category:
       <select name="book">
       <option>Fictional</option>
       <option>Non-fictional</option>
       <option>others</option>
       </select>
       <br><br>

       Quantity:
       <input type="number" name="quantity" min="1" required>
       <br><br>

       <button type="submit">Place order</button>

       <a href="/orders">View Orders</a>
       
       </form>
       <br>
        `)
})

app.post("/orders",(req,res)=>
{
    const order = {
        id:orders.length + 1, 
        customer: req.body.customer, 
        book: req.body.book, 
        quantity: req.body.quantity
    }; 

    orders.push(order);

    res.send(
        
        `
        <h2> Order Placed Successfully! </h2>
        <p> Order ID : ${order.id}</p>
        <p> Customer: ${order.customer}</p>
        <p> Book: ${order.book}</p>
        <p>Quantity: ${order.quantity}</p>

        <br>

        <a href="/">Place another Order </a>
        `);
})

app.get("/orders", (req, res) =>
{
    res.json(orders);
})


app.listen(3000, () =>
{
    console.log("Server is running");
});