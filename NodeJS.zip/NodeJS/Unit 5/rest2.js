const express = require("express"); 
const app = express(); 

app.use(express.urlencoded({extended:true}))
app.use(express.json())

let orders = [];

//display form 
app.get("/", (req, res) =>
{
    res.send(
        `
       <h2>Food Ordering Page</h2>
       <form action = "/orders" method="POST">

       <label>Customer Name: </label>
       <input type = "text" name="customer" required>
       <br><br>

       <label>Food</label>
       <select name="food">
       <option>Pizza</option>
       <option>Burger</option>
       <option>Pasta</option>
       </select>
       <br><br>

       <label>Quantity:</label>
       <input type="number" name="quantity" min="1" required>
       <br><br>

       <button type="submit">Place order</button>

       <a href="/orders">View Orders</a>
       
       </form>
       <br>
        `)
})

//post 
app.post("/orders", (req, res) =>
{
    const order = {
        id:orders.length + 1, 
        customer: req.body.customer, 
        food: req.body.food, 
        quantity: req.body.quantity
    }; 

    orders.push(order);

    res.send(
        `
        <h2> Order Placed Successfully! </h2>
        <p> Order ID : ${order.id}</p>
        <p> Customer: ${order.customer}</p>
        <p> Food: ${order.food}</p>
        <p>Quantity: ${order.quantity}</p>

        <br>

        <a href="/">Place another Order </a>
        `);
});

//get 
app.get("/orders", (req, res) =>
{
    res.json(orders);
})

app.listen(3000, () =>
{
    console.log("Server is running");
});