const express = require("express");
const app = express();

app.use(express.json());

let products = [
    {id:1,name:"Laptop",price:68799},
    {id:2,name:"Mobile",price:40000}
];

//GET all the products
app.get("/products",(req,res)=>{
    res.json(products);
});

//POST - add the product
app.post("/products",(req,res)=>{
    const product = {
        id: products.length + 1,
        name: req.body.name,
        price: req.body.price 
    };

    products.push(product);

    res.status(201).json({
        message: "Product Added",
        product: product
    });
})


//PUT - Update the product
app.put("/products/:id", (req, res) => {
    const id = Number(req.params.id);
    const product = products.find(p => p.id === id);

    if(!product) {
        return res.status(404).json({ message: "Product not found" });
    }

    product.name = req.body.name;
    product.price = req.body.price;

    res.json({
        message: "Product updated !",
        product: product
    })
});

//DELETE A PRODUCT
app.delete("/products/:id",(req,res)=>
{
    const id=Number(req.params.id);
    products =products.filter(p => p.id !== id);

    res.json({
        message:"Product deleted"
    });
})

app.listen(3000,()=>{
    console.log("Server running.....")
});
