const express=require("express")
const {Pool}=require("pg")
const app=express()

//middleware
app.use(express.urlencoded({extended:true}))
app.use(express.static(__dirname));

//object of pool
const db=new Pool({
    user:"postgres",
    password:"1234",
    database:"collegedb",
    host:"localhost",
    port:5432
})

app.post("/add",async(req,res)=>
{
    const {name,age}=req.body

    await db.query(
        "INSERT INTO students (name,age) VALUES($1,$2)",
        [name,age]
    );
    res.send("Student added Successfully !!");
})

app.get("/students",async(req,res)=>
{
    const result=await db.query("SELECT * from students");
    res.json(result.rows);
})

//update
app.post("/update",async(req,res)=>
{
    const {id,name,age}=req.body
    await db.query(
        "UPDATE students SET name=$1,age=$2 where id=$3",
        [name,age,id]
    );
    res.redirect("/")
})

//update course
app.post("/update-course",async(req,res)=>
{
    const {id,course}=req.body
    await db.query(
        "UPDATE students SET course=$1 where id=$2",
        [course,id]
    );
    res.redirect("/")
})

//delete student
app.post("/delete",async(req,res)=>
{
    const {id}=req.body
    await db.query(
        "DELETE FROM students where id=$1",
        [id]
    );
    res.send("Student deleted");
    res.redirect("/")
    
})


app.listen(3000,()=>
{
    console.log("Server running...");
})



//create a node application in which library management is done for cse
//user should add a book -name,book_id,price,author,edition
//user can update the book
//user can get the list of existing books.  