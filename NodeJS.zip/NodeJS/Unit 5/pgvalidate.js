const express = require("express");
const { Pool } = require("pg");
const { body, validationResult } = require("express-validator");

const app = express();


// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
  

// PostgreSQL connection
const pool = new Pool({
    user: "postgres",
    host: "localhost",
    database: "students",
    password: "",    // CHANGE THIS
    port: 5432
});


// Home page
app.get("/", (req, res) => {
    res.send(`
        <h1>Student Registration</h1>

        <form action="/register" method="POST">

            <label>Name:</label>
            <input type="text" name="name">
            <br><br>

            <label>Email:</label>
            <input type="text" name="email">
            <br><br>

            <label>Age:</label>
            <input type="number" name="age">
            <br><br>

            <button type="submit">Register</button>

        </form>
    
`);
});


// Register student
app.post(
    "/register",

    // Validation
    [
        body("name")
            .trim()
            .notEmpty()
            .withMessage("Name is required"),

        body("email")
            .trim()
            .isEmail()
            .withMessage("Enter a valid email"),

        body("age")
            .isInt({ min: 18, max: 100 })
            .withMessage("Age must be between 18 and 100")
    ],

    async (req, res) => {

        // Get validation errors
        const errors = validationResult(req);

        if (!errors.isEmpty()) {
            return res.status(400).send(
                <h2>Validation Errors</h2>

                <ul>
                    ${errors.array()
                        .map(error => <li>${error.msg}</li>)
                        .join("")}
                </ul>
    
                <a href="/">Go Back</a>
            );
        }


        // Get form data
        const { name, email, age } = req.body;


        try {

            // Insert into PostgreSQL
            const result = await pool.query(
                INSERT INTO students (name, email, age)
                 VALUES ($1, $2, $3)
                 RETURNING *,
                [name, email, age]
            );


            res.send(
                <h2>Student Registered Successfully!</h2>

                <p><b>ID:</b> ${result.rows[0].id}</p>
                <p><b>Name:</b> ${result.rows[0].name}</p>
                <p><b>Email:</b> ${result.rows[0].email}</p>
                <p><b>Age:</b> ${result.rows[0].age}</p>

                <a href="/">Register Another Student</a>
            );

        } catch (error) {

            console.log(error);

            res.status(500).send("Database error");
        }
    }
);


// Start server
app.listen(3000, () => {
    console.log("Server running at http://localhost:3000");
});