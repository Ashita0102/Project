const express = require("express");
const { Pool } = require("pg");

const app = express();

app.use(express.urlencoded({ extended: true }));
app.use(express.json());

const pool = new Pool({
    user: "postgres",
    host: "localhost",
    database: "college",
    password: "1234",
    port: 5432
});

// Show form
app.get("/", (req, res) => {
    res.send(`
        <h2>Student Registration</h2>

        <form method="POST" action="/register">

            Name:
            <input type="text" name="name" required>
            <br><br>

            Email:
            <input type="text" name="email" required>
            <br><br>

            Age:
            <input type="number" name="age" required>
            <br><br>

            Password:
            <input type="text" name="password" required>
            <br><br>

            Rollno:
            <input type="number" name="rollno" required>
            <br><br>

            <button type="submit">Register</button>

        </form>
    `);
});

// Form submission
app.post("/register", async (req, res) => {

    const { name, email, age } = req.body;

    // Server-side validation
    if (!name || !email || !age) {
        return res.send("All fields are required");
    }

    if (name.length < 3) {
        return res.send("Name must contain at least 3 characters");
    }

    if (!email.includes("@")) {
        return res.send("Enter a valid email");
    }

    if (age < 18) {
        return res.send("Age must be 18 or above");
    }

    try {

        await pool.query(
            "INSERT INTO students (name, email, age) VALUES ($1, $2, $3)",
            [name, email, age]
        );

        res.send("Student registered successfully!");

    } catch (error) {

        console.log(error);
        res.send("Error while registering student");
    }
});

app.listen(3000, () => {
    console.log("Server running on http://localhost:3000");
});