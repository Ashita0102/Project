# messy_script.py

import csv
import os

# Global variables - bad for testability and reusability
input_filename = "users_raw.csv"
output_filename = "users_processed.csv"
min_age = 18

def process_users_data():
   
    users_data = []
    try:
        with open(input_filename, 'r', newline='') as infile:
            reader = csv.reader(infile)
            header = next(reader) # Skip header
            for row in reader:
                try:
                    name = row[0]
                    age = int(row[1])
                    users_data.append({'name': name, 'age': age})
                except (ValueError, IndexError):
                    # Silent failure for bad rows
                    print(f"Skipping malformed row: {row}")
                    pass
    except FileNotFoundError:
        print(f"Error: Input file '{input_filename}' not found.")
        return
    except Exception as e:
        pass

    processed_users = []
    for user in users_data:
        if user['age'] >= min_age: # Uses global min_age
            processed_users.append({'name': user['name'].upper(), 'age': user['age']})

    try:
        with open(output_filename, 'w', newline='') as outfile:
            writer = csv.writer(outfile)
            writer.writerow(['NAME', 'AGE']) # Write header
            for user in processed_users:
                writer.writerow([user['name'], user['age']])
    except Exception as e:
        pass 

    print(f"Processed data written to '{output_filename}'")

if __name__ == "__main__":
    # Create a dummy input file for demonstration
    if not os.path.exists(input_filename):
        with open(input_filename, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(['Name', 'Age'])
            writer.writerow(['Alice', '25'])
            writer.writerow(['Bob', '16'])
            writer.writerow(['Charlie', '30'])
            writer.writerow(['David', '17'])
            writer.writerow(['Eve', '22'])
            writer.writerow(['Frank', 'abc']) # Malformed row
            writer.writerow(['Grace']) # Malformed row

    process_users_data()







import csv


MIN_AGE = 18


def read_users(filename):
    users = []

    try:
        with open(filename, "r", newline="") as file:
            reader = csv.DictReader(file)

            for row in reader:
                try:
                    users.append({
                        "name": row["Name"],
                        "age": int(row["Age"])
                    })
                except (ValueError, KeyError):
                    print(f"Skipping malformed row: {row}")

    except FileNotFoundError:
        print(f"Error: File '{filename}' not found.")

    return users


def filter_users(users, min_age=MIN_AGE):
    return [user for user in users if user["age"] >= min_age]


def process_users(users):
    return [
        {
            "name": user["name"].upper(),
            "age": user["age"]
        }
        for user in users
    ]


def write_users(filename, users):
    with open(filename, "w", newline="") as file:
        writer = csv.writer(file)

        writer.writerow(["NAME", "AGE"])

        for user in users:
            writer.writerow([user["name"], user["age"]])


def process_users_data(input_file, output_file, min_age=MIN_AGE):
    users = read_users(input_file)
    filtered_users = filter_users(users, min_age)
    processed_users = process_users(filtered_users)
    write_users(output_file, processed_users)

    print(f"Processed data written to '{output_file}'")


def create_sample_file(filename):
    data = [
        ["Name", "Age"],
        ["Alice", "25"],
        ["Bob", "16"],
        ["Charlie", "30"],
        ["David", "17"],
        ["Eve", "22"],
        ["Frank", "abc"],
        ["Grace"]
    ]

    with open(filename, "w", newline="") as file:
        writer = csv.writer(file)
        writer.writerows(data)


if __name__ == "__main__":
    input_file = "users_raw.csv"
    output_file = "users_processed.csv"

    create_sample_file(input_file)
    process_users_data(input_file, output_file)


#     pytest>=8.0.0
# pytest-html>=4.1.0
# pytest -v .\test_clean_modules.py

# Eileen Leonard Mascarenhas
# 6:05 PM
# pytest .\test_clean_modules.py  --html=report.html