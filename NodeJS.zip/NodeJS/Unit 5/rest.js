const express=require("express")
const app=express()

app.use(express.json())
app.use(express.urlencoded({extended:true}))

//data
let students=[
    {id:1, name:"abc", course:"CSE"},
    {id:2, name:"xyz", course:"MBA"}
]

//read the data
app.get("/students",(req,res)=>
{
    res.json(students)
})

//read data as per id given by user
app.get("/students/:id",(req,res)=>
{
    const id=parseInt(req.params.id);
    const student=students.find(s=>s.id ===id)
    if(!student)
    {
        res.status(404).send("Student not found");
    }
})

//update the data
app.put("/students/:id",(req,res)=>
{
    const id=parseInt(req.params.id);
    const student=students.find(s=>s.id ===id)
    if(!student)
    {
        res.status(404).send("Student not found");
    }
    student.name=req.body.name
    student.course=req.body.course
})


app.get("/",(req,res)=>
{
   res.send(`
        <form method="POST" action="/add">

            Name:
            <input type="text" name="name" required>
            <br><br>

            Course:
            <input type="text" name="email" required>
            <br><br>

            <button type="submit">Add student</button>

        </form>
   `)
})

app.post("/students",(req,res)=>
{
    const student={
        id:students.length +1,
        name: req.body.name,
        course: req.body.course
    };

    students.push(student);

    res.send(`
        <h2>Student Added Successfully!!</h2>
        <p>ID: ${student.id}</p>
        <p>Name: ${student.name}</p>
        <p>Course: ${student.course}</p>
        <br>
        <a href="/">Add Another Student </a>
        <br>
        <a href="/students">View All Student</a>
        `)
})
//start the server
app.listen(3000,()=>
{
    console.log("Server running ....");
})