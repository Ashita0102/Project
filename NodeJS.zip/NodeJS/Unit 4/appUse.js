const express=require("express")

const app=express()

//get
app.get("/",(req,res)=>
{
    res.send("Welcome to express");

})

//post
app.post("/login",(req,res)=>
{
    res.send("Login successful")
});

//put
app.put("/user",(req,res)=>
{
    res.send("User updated");
})

//delete
app.delete("/user",(req,res)=>
{
    res.send("User deleted")
})

app.listen((3000),()=>
{
    console.log("Server is running")
})
