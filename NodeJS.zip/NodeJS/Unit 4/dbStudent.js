import express from "express"
import mongoose, { Model, mongo } from "mongoose"

const app=express()

//middleware
app.use(express.urlencoded({extended:true}));

//connect
mongoose.connect("mongodb://localhost:27017/")

//schema
const StudentSchema=new mongoose.Schema({
    name:String,
    age:Number,
    course:String
});

//model
const Student=mongoose.model("students",StudentSchema)

//home page
app.get("/",(req,res)=>
{
    res.send(`
        <h1>Student Management System</h1>

        <!--Create-->
        <h2> 1.Add student</h2>
        <form action="/add" method="post">
        <input type="text" name="name" placeholder="Enter name"><br><br>
        <input type="number" name="age" placeholder="Enter age"><br><br>
        <input type="text" name="course" placeholder="Enter course"><br><br>
        <button type="submit">Add Student</button>
        </form>

        <hr>

        <!--read-->
        <h2> 2.View Students</h2>
        <form action="/read" method="post">
        <button type="submit">Show Students</button>
        </form>

        <hr>

        <!--update-->
        <h2> 3. Update Student</h2>
        <form action="/update" method="post">
        <input type="text" name="id" placeholder="student ID"><br><br>
        <input type="text" name="name" placeholder="new name"><br><br>
        <input type="number" name="age" placeholder="new age"><br><br>
        <input type="text" name="course" placeholder="new course"><br><br>
        <button type="submit">Update Student</button>
        </form>

        <hr>

        <!--delete-->
        <h2> 4.Delete Student</h2>
        <form action="/delete" method="post">
        <input type="text" name="id" placeholder="Student id"><br><br>
        <button type="submit">Delete Student</button>
        </form>



        `)
})

//create
app.post("/add", async (req, res) => {

    const student = new Student({
        name: req.body.name,
        age: req.body.age,
        course: req.body.course
    });

    const result = await student.save();

    res.send(`
        <h2>Student Added Successfully</h2>
        <p>Name: ${result.name}</p>
        <p>Age: ${result.age}</p>
        <p>Course: ${result.course}</p>
        <br>
        <a href="/">GO BACK</a>
    `);
});

//read
app.post("/read",async(req,res)=>
{
    const students=await Student.find()

    let table=`
    <h2>All Students</h2>
    <table border="1" cellpadding="10">
    <tr>
    <th>Name</th>
    <th>Age</th>
    <th>Course</th>
    <th>ID</th>
    </tr>
    `;

    students.forEach(student => {
        table +=`
        <tr>
        <td>${student.name}</td>
        <td>${student.age}</td>
        <td>${student.course}</td>
        <td>${student._id}</td>
        `
    });

    table +=`
    </table>
    <br>
    <a href="/">GO BACK</a>
    `;
    res.send(table);

})

//update
app.post("/update",async(req,res)=>
{
    const result=await Student.updateOne(
        {
            _id:req.body.id
        },
        {
            $set:{
                name:req.body.name,
                age:req.body.age,
                course:req.body.course
            }
        }
    )
    res.send(`
        <h2>Student Updated</h2>
        <p>Matched:${result.matchedCount}</p>
        <p>Modified:${result.modifiedCount}</p>
        <br>
        <a href="/">GO BACK </a>
        `)
})

//delete
app.post("/delete",async(req,res)=>
{
    const result=await Student.deleteOne({
        _id:req.body.id
    })
    res.send(`
        <h2>Student Deleted</h2>
        <p>Delete count: ${result.deletedCount}</p>
        <a href="/"> GO BACK</a>
        
        `)
})
app.listen(3000);