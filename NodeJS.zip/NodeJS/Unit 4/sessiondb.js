const express=require("express")
const mongoose=require("mongoose")
const session=require("express-session")
const MongoStore=require("connect-mongo").default;

const app=express()

//connect Mongodb
mongoose.connect("mongodb://localhost:27017/db")
.then(()=>console.log("Mongodb connected"))
.catch(err=> console.log(err));

//session
app.use(
    session({
        secret:"mysecret",
        resave:false,
        saveUninitialized:false,  //true for again and again changes

        store:MongoStore.create({
            mongoUrl:"mongodb://localhost:27017/db"
        }),

        cookie:{
            maxAge:1000*60*60
        }
    })
);

//login
app.get("/login",(req,res)=>
{
    req.session.username="ABC"
    res.send("Login Successfull");
})

//profile
app.get("/profile",(req,res)=>
{
    if(req.session.username)
    {
        res.send("Welcome "+req.session.username)
    }
    else{
        res.send("Please login first")
    }
})

//logout
app.get("/logout",(req,res)=>
{
    req.session.destroy();
    res.send("Logout Successful");
});

//start the server
app.listen(3000,()=>
{
    console.log("Server Running...")
})