const express=require("express")
const mongoose= require("mongoose")

const app=express()
app.use(express.urlencoded({extended:true}))

//mongoDB connection
mongoose.connect("mongodb://localhost:27017/")
.then(()=> console.log("MongoDB connected"))
.catch(err => console.log(err))

//user schema
const userSchema=new mongoose.Schema({
    email : String,
    password :String
});

const User=mongoose.model("User", userSchema);
app.get("/",(req,res)=>
{
    res.sendFile(__dirname + "/logindb.html")
})

//login
app.post("/login",async(req,res)=>
{
    const email=req.body.email;
    const password=req.body.password;

    console.log("Email: ",email)
    console.log("Password: ",password)
    const user=await User.findOne({
        email:email,
        password:password
    });
    if(user)
    {
        res.send("Login successful");
    }
    else{
        res.send("Invalid email or password")
    }
});
app.listen(3000,(req,res)=>
{
    console.log("Server is running");
})