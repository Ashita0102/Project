const express=require("express")
const app=express()

app.all("/hello",(req,res)=>
{
    res.send("Hello!! you used " +req.method);
})

app.listen(3000);