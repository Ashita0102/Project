const fs=require("fs")

//write in a file
fs.writeFile("demo.txt","Hello Node",(err)=>
{
    if(err)
        throw err
    console.log("Writing in file is done");

    //read the file
    fs.readFile("demo.txt","utf-8",(err,data)=>
    {
        if(err)
            throw err
        console.log("File content: ",data);

    //append file
    fs.appendFile("demo.txt","\nWelcome to the class",(err)=>{

        if(err) throw err;
        console.log("Data is appended");

        fs.unlink("demo.txt",(err)=>{
            console.log("File deleted");
        })
        
    })
    
    })
})

