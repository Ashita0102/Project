const fs=require('fs')

//write in a file
fs.writeFileSync("demo.txt","Hello Node");
console.log("File is created and data written");

//read the file
const data=fs.readFileSync("demo.txt","utf-8")
console.log("File created: ",data);

//Append file
fs.appendFileSync("demo.txt","\n Welcome to NodeJS");
console.log("Data appended successfully");

//Delete the file
fs.unlinkSync("demo.txt");
console.log("File deleted successfully");