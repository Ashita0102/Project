//write a nodejs code to copy content from one source file to another destination file
const fs=require("fs")
fs.copyFile("demo1.txt","demo2.txt",(err)=>
{
    console.log("File copied !!");
});
