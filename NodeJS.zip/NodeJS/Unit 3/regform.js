//create a form with name and reg no of the student.
//the details should be set in a cookie,fetch the details
//from cookie and delete the cookie after 30sec
const express=require("express")
const app=express()

app.use(express.urlencoded({extended:true}))

app.get("/",(req,res)=>
{
    <form action='/set-cookie' method="post">
        Name:
        <input type="text"></input><br></br>
        Reg No:
        <input type="number"></input><br></br>
        <input type="submit" value='set-ccokie'></input>
    </form>
})



app.listen(3000)