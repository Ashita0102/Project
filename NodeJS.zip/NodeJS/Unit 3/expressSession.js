const express=require("express")
const session=require("express-session")
const app=express()

app.use(express.urlencoded({extended:true}))

//session setup
app.use(session({
    secret:'mysecretKey',
    resave:false,
    saveUninitialized:true
}))

//home page
app.get("/",(req,res)=>
{
    res.send(`
        <form action="/login" method="post">
        <input type="text" name="username" placeholder="Enter username">
        <button>Login</button>
        </form>
        <a href="/profile">GO TO PROFILE</a>
        `)
})

app.post("/login",(req,res)=>
{
    const name=req.body.username;
    //save this in the session
    req.session.user=name
    res.send(`
        Session created for ${name} <br>
        `)
})

//profile page
app.get('/profile',(req,res)=>
{
    if(req.session.user)
    {
        res.send(`Welcome ${req.session.user}!
            <br>
            <a href="/logout">LOGOUT</a>
            `)
    }
    else
    {
        res.send(`
            no session found
            <br>
            <a href="/logout">LOGOUT</a>
            `)
    }
})

//logout
app.get("/logout",(req,res)=>
{
    res.send(`
        LOGOUT! <br>
        <a href="/">HOME</a>
        `)
});

app.listen(3000)

//create a system for your Club
//use session and store the details of the members of your club
//using express-session