//cookie session
const express=require("express")
const cookieSession=require("cookie-session")
const app=express()

app.use(express.urlencoded({extended:true}))

app.use(
    cookieSession({
        name:"cabBooking",
        keys:["mySecretKey"]
    })
);

//home page
app.get("/",(req,res)=>
{
    res.send(`
        <h1>Cab Booking </h1>
        <form action="/book" method="post">
        <label>Pickup Location: </label>
        <input type="text" name="pickup" required>
        <label>Destination</label>
        <input type="text" name="destination" required>
        <br><br>
        <label>Cab Type: </label>
        <select name="cabType">
        <option value="Mini">Mini</option>
        <option value="Sedan">Sedan</option>
        <option value="SUV">SUV</option>
        </select>
        <button type="submit">Book Cab</button>
        </form>
        `)
})

app.post("/book",(req,res)=>
{
    const pickup=req.body.pickup;
    const destination=req.body.destination;
    const cabType=req.body.cabType;

    //store the details
    req.session.pickup=pickup;
    req.session.destination=destination;
    req.session.cabType=cabType;

    res.send(`
        <h1>Cab Booked!!</h1>
        <p><b>Pickup: </b> ${pickup}</p>
        <p><b>Destination: </b>${destination}</p>
        <p><b>Cab Type: </b> ${cabType}</p>
        <br>
        <a href="/">Book Another Cab</a>
        <br><br>
        <form action="cancel" method="post">
        <button type="submit">Cancel Booking</button>
        </form>
        }
        `)

})

//cancel booking
app.post('/cancel',(req,res)=>
{
    res.session=null
    res.send(`
    <h1>Booking Cancel</h1>
    <p>Your cab has been canceled</p>
    <a href="/">Go BACK</a>
    `)
    
})
app.listen(3000)
