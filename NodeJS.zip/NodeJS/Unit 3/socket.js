const express=require('express')
const app=new express()
const Server=require('socket.io')
var server=app.listen('5003',()=>
{
    console.log("Connected to localhost")
})

var io=Server(server)
app.get('/',(req,res)=>
{
    res.sendFile(__dirname+'/client.html')
})
io.on("connection",(socket)=>
{
    console.log("user connected")
    socket.on('myname',(name)=>
    {
        io.emit('myname',name)
    })
    socket.on('chatm',(msg)=>
    {
        io.emit('chatm',msg)
    })
})