const cookieSession = require('cookie-session');
var session=require('cookie-session')   //npm install express cookie-session
var express=require('express')
var obj=new express()
const port=3000;

//middleware
obj.use(session({
    name:"session",
    keys:['secret-key'],
    maxAge:5*60*1000
}))

obj.get('/set-session',(req,res)=>
{
    req.session.user="abc"
    req.session.city="xyz"
    res.send(`session set! <a href="/get-session"> GET SESSION </a>`)
})

//get session
obj.get('/get-session',(req,res)=>
{
    var user=req.session.user
    var city=req.session.city
    res.send(`Stored session for ${user} and ${city}
        <a href="/delete-session"> DELETE SESSION </a>
        `)
})

//delete session
obj.get('/delete-session',(req,res)=>
{
    req.session=null
    res.send(`Session is destroyed
        <a href="/get-session">GET SESSION</a>`)
})
obj.listen(3000)