const express=require("express")
const app=express()
const router=express.Router()

//router level mmiddleware
router.use((req,res,next)=>
{
    console.log("user middleware");
    next();
});

//route inside route
router.get("/profile",(req,res)=>
{
    res.send("User profile")
});

//connect router to app
app.use("/user",router);

app.get("/home",(req,res)=>
{
    res.send("Home page")
})

app.listen(3000);