const express=require('express')
const cookieParser=require('cookie-parser')
const app=express()

app.use(cookieParser())
app.use(express.urlencoded({extended:true}))

app.get("/",(req,res)=>
{
    const savedColor=req.cookies.favouriteColor || "No color saved yet"
    
    res.send(`
        <h1>Favourite Color Form</h1>
        <p>Last saved color: ${savedColor} </p>

        <form action="/save-color" method="post">
        <label>Enter your favourite color</label>
        <input type="text" name="color" required>
        <button type="submit">Save color</button>
        </form>
        `)
})

app.post("/save-color",(req,res)=>
{
    const color=req.body.color;
    res.cookie("favoriteColor",color)
    res.send(`
        <h2>Color saved successfully!!</h2>
        <p>Your favourite color is <b> ${color}</b> has been saved as a cookie. </p>
        <a href="/">GO BACK</a>
        `)
})

app.listen(3000)
