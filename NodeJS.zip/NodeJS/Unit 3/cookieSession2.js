const express=require("express")
const cookieSession=require("cookie-session")
const app=express()
app.use(express.urlencoded({extended:true}))
app.use(cookieSession({
    name:"session",
    keys:["my-secret-key"]
}))
app.get("/",(req,res)=>
{
    res.send(`
        <h1>Login</h1>
        <form action="/login" method="post">
        <input type="text" name="username" placeholder="Enter username">
        <button type=submit">LOGIN</button>
        </form>
        `)
})

app.post("/login",(req,res)=>
{
    req.session.user=req.body.username;
    res.send(`
        <h1>Login successful</h1>
        <p>Welcome ${req.session.user}</p>

        <a href="/profile">Go to Profile</a>
        `)
})

app.get("/profile",(req,res)=>
{
    res.send(`
        <h1>Profile Page</h1>
        <p>Hello ${req.session.user}</p>
        <a href="/logout">LOGOUT</a>
        `)
})

app.get("/logout",(req,res)=>
{
    req.session=null;
    res.send(`
        <h1>Logout Successful</h1>
        <a href="/">LOGIN AGAIN!</a>
        `)
})

app.listen(3000)