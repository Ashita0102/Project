//WAP of custom middleware, in whichhome page should display
//a welcome message with the same name of user and create route
// /user/department to display department of user 