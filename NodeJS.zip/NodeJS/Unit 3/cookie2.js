//user cookie-parse to display the employees's department
//name of the cookie should be department
const express=require('express')
const cookieParser=require('cookie-parser')  //npm install

const app=express()
app.use(cookieParser()) //middleware

//setting a cookie
app.get('/set-cookie',(req,res)=>
{
    res.cookie('cse','ashita',{maxAge:20000}) //cookie set for 1 min
    res.send('cookie has been set');
})

//read the cookie
app.get('/getcookie',(req,res)=>
{
    res.send(`Product Cookie : ${req.cookies.product}`)
})

//clear the cookie
app.get('/clearcookie',(req,res)=>
{
    res.clearCookie('product')
    res.send('cookie is cleared');
})

//start the server
app.listen(3000,()=>
{
    console.log("cookie is running")
})