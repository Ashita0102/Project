const express=require("express")
const app=express()

//application-level middleware
app.use((req,res,next)=>
{
    console.log("Middleware executed");
    next();
})

app.get("/",(req,res)=>
{
    res.send("Home page")
});

app.get("/about",(req,res)=>
{
    res.send("This is my about page")
});

app.get("/contact",(req,res)=>
{
    res.send("contact page")
});

app.get("/profile",(req,res)=>
{
    res.send("Profile page")
});

app.listen(3000);