var express=require('express')
var obj=new express()
var cookieParser =require('cookie-parser')

obj.use(cookieParser())
obj.use(express.urlencoded({extended:true}))

obj.get("/",(req,res)=>
{
    res.sendFile(__dirname + '/cookie.html')
})

//set the cookie
obj.post('/set-cookie',(req,res)=>
{
    const theme2=req.body.theme1;
    res.cookie('theme',theme2,{maxAge:5000})
    res.send(`Theme set for ${theme2}\
        <a href='/get-cookie'>GET Cookie</a>
        `)
})

//get the cookie
obj.get('/get-cookie',(req,res)=>
{
    const theme3=req.cookies.theme
    res.send(`Cookie fetched and it is ${theme3} mode
        <a href='/delete-cookie'>DELETE Cookie</a>
        `)
})

//delete the cookie
obj.get('/delete-cookie',(req,res)=>
{
    res.clearCookie('theme')
    res.send(`Cookie cleared 
        <a href='/'>HOME</a>
        `)
})
obj.listen(3000);