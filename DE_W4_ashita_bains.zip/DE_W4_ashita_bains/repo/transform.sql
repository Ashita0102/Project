
-- Week 3: RetailCo data transformation
-- Keep staging_retailco unchanged.

DROP TABLE IF EXISTS transformed_retailco;

CREATE TABLE transformed_retailco AS
SELECT
    staging_row_id AS source_row_number,
    NULLIF(TRIM(transaction_id), '') AS transaction_id,
    NULLIF(TRIM(store_id), '') AS store_id,
    NULLIF(TRIM(store_name), '') AS store_name,

    
CASE
    WHEN TRIM(transaction_date) ~ '^[0-9]{4}-[0-9]{2}-[0-9]{2}$'
        THEN TO_DATE(TRIM(transaction_date), 'YYYY-MM-DD')
    WHEN TRIM(transaction_date) ~ '^[0-9]{2}-[0-9]{2}-[0-9]{4}$'
        THEN TO_DATE(TRIM(transaction_date), 'DD-MM-YYYY')
    WHEN TRIM(transaction_date) ~ '^[0-9]{2}/[0-9]{2}/[0-9]{4}$'
        THEN TO_DATE(TRIM(transaction_date), 'DD/MM/YYYY')
    ELSE NULL
END AS transaction_date,


    NULLIF(TRIM(customer_id), '') AS customer_id,
    NULLIF(TRIM(product_code), '') AS product_code,
    NULLIF(TRIM(product_name), '') AS product_name,
    NULLIF(TRIM(category), '') AS category,

    NULLIF(TRIM(quantity), '')::INTEGER AS quantity,
    NULLIF(TRIM(unit_price_inr), '')::NUMERIC(12,2) AS unit_price_inr,
    NULLIF(TRIM(total_amount_inr), '')::NUMERIC(14,2) AS total_amount_inr,
    NULLIF(TRIM(discount_pct), '')::NUMERIC(5,2) AS discount_pct,

    NULLIF(TRIM(payment_method), '') AS payment_method,
    NULLIF(TRIM(cashier_id), '') AS cashier_id,
    NULLIF(TRIM(region), '') AS region,
    NULLIF(TRIM(city), '') AS city

FROM staging_retailco;
