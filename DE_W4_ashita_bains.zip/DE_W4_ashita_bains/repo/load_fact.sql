
-- Week 3: Load RetailCo fact table
-- Preserve all source rows, including duplicate transaction IDs.

INSERT INTO fact_sales (
    source_row_number,
    transaction_id,
    date_key,
    store_key,
    product_key,
    customer_key,
    cashier_key,
    payment_method,
    quantity,
    unit_price_inr,
    total_amount_inr,
    discount_pct
)
SELECT
    t.source_row_number,
    t.transaction_id,
    TO_CHAR(t.transaction_date, 'YYYYMMDD')::INTEGER,
    s.store_key,
    p.product_key,
    c.customer_key,
    ca.cashier_key,
    t.payment_method,
    t.quantity,
    t.unit_price_inr,
    t.total_amount_inr,
    t.discount_pct
FROM transformed_retailco t
JOIN dim_date d
    ON d.full_date = t.transaction_date
JOIN dim_store s
    ON s.store_id = t.store_id
JOIN dim_product p
    ON p.product_code = t.product_code
LEFT JOIN dim_customer c
    ON c.customer_id = t.customer_id
LEFT JOIN dim_cashier ca
    ON ca.cashier_id = t.cashier_id
WHERE t.transaction_date IS NOT NULL
  AND t.transaction_id IS NOT NULL
  AND t.store_id IS NOT NULL
  AND t.product_code IS NOT NULL
  AND t.payment_method IS NOT NULL
ON CONFLICT (source_row_number) DO NOTHING;
