﻿# RetailCo End-to-End Data Engineering Pipeline

## Project Overview

This project integrates the Week 2 data ingestion pipeline with the Week 3 dimensional data warehouse for RetailCo transaction data.

The objective is to create a reproducible workflow that processes raw retail transaction data, prepares it for warehouse loading, and validates the resulting warehouse data.

## Project Structure

- `ingest.py` — Week 2 ingestion pipeline.
- `tests/` — ingestion pipeline tests.
- `schema.sql` — creates warehouse and staging structures.
- `staging.sql` — prepares the staging layer.
- `transform.sql` — transforms transaction data.
- `load_dimensions.sql` — loads dimension tables.
- `load_fact.sql` — loads the sales fact table.
- `validation.sql` — validates warehouse data.
- `specs/week-02-ingestion.md` — Week 2 ingestion specification.
- `specs/week-03-warehouse.md` — Week 3 warehouse specification.
- `STATUS.md` — integration progress and validation status.
- `DECISIONS.md` — technical decisions and constraints.
- `RUN_OUTPUT.txt` — recorded output from the end-to-end run.
- `DEMO_LINK.txt` — demonstration link or its status.

## Pipeline Workflow

1. Read the raw RetailCo transaction CSV.
2. Validate the expected input columns and transaction data.
3. Normalize transaction dates and handle missing identifiers and duplicate records according to the ingestion rules.
4. Prepare the staging data.
5. Create and populate the warehouse staging and transformed tables.
6. Load the dimension tables.
7. Load the sales fact table.
8. Run warehouse validation queries.

## Technology Stack

- Python for data ingestion.
- SQL for staging, transformation, warehouse loading, and validation.
- PostgreSQL 18 for the Week 3 warehouse implementation.
- Git for version control and integration of Week 2 and Week 3 histories.

## Database Compatibility

The Week 3 warehouse was executed using PostgreSQL 18 because MySQL installation was blocked by the environment's security restrictions. The SQL scripts must be tested against the configured PostgreSQL database; this repository does not claim that the scripts have been verified on MySQL.

## Data Quality Considerations

The source dataset contains mixed transaction date formats, missing customer and cashier identifiers, and duplicate records. These cases must be handled consistently across ingestion and warehouse processing.

## Running the Project

Run the ingestion script using the input and output paths supported by `ingest.py`. Then execute the warehouse SQL scripts in their required dependency order against the configured PostgreSQL database.

The exact commands and required paths will be documented after verifying the script arguments and database dependencies.

## Specifications

- Week 2: `specs/week-02-ingestion.md`
- Week 3: `specs/week-03-warehouse.md`

## Integration Status

The Week 2 and Week 3 histories are being integrated into the Week 4 repository. End-to-end execution and validation must be recorded in `RUN_OUTPUT.txt` after a fresh run.
