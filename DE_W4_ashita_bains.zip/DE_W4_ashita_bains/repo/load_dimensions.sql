
-- Week 3: Load RetailCo dimension tables
-- PostgreSQL

-- 1. Date dimension
INSERT INTO dim_date (
    date_key,
    full_date,
    day_of_month,
    month_number,
    quarter_number,
    year_number
)
SELECT DISTINCT
    TO_CHAR(transaction_date, 'YYYYMMDD')::INTEGER,
    transaction_date,
    EXTRACT(DAY FROM transaction_date)::SMALLINT,
    EXTRACT(MONTH FROM transaction_date)::SMALLINT,
    EXTRACT(QUARTER FROM transaction_date)::SMALLINT,
    EXTRACT(YEAR FROM transaction_date)::SMALLINT
FROM transformed_retailco
WHERE transaction_date IS NOT NULL
ON CONFLICT (date_key) DO NOTHING;

-- 2. Store dimension
INSERT INTO dim_store (store_id, store_name, city, region)
SELECT DISTINCT store_id, store_name, city, region
FROM transformed_retailco
WHERE store_id IS NOT NULL
ON CONFLICT (store_id) DO NOTHING;

-- 3. Product dimension
INSERT INTO dim_product (product_code, product_name, category)
SELECT DISTINCT product_code, product_name, category
FROM transformed_retailco
WHERE product_code IS NOT NULL
ON CONFLICT (product_code) DO NOTHING;

-- 4. Customer dimension: do not invent missing IDs
INSERT INTO dim_customer (customer_id)
SELECT DISTINCT customer_id
FROM transformed_retailco
WHERE customer_id IS NOT NULL
ON CONFLICT (customer_id) DO NOTHING;

-- 5. Cashier dimension: do not invent missing IDs
INSERT INTO dim_cashier (cashier_id)
SELECT DISTINCT cashier_id
FROM transformed_retailco
WHERE cashier_id IS NOT NULL
ON CONFLICT (cashier_id) DO NOTHING;

-- Verify dimension counts
SELECT 'dim_date' AS table_name, COUNT(*) AS row_count FROM dim_date
UNION ALL
SELECT 'dim_store', COUNT(*) FROM dim_store
UNION ALL
SELECT 'dim_product', COUNT(*) FROM dim_product
UNION ALL
SELECT 'dim_customer', COUNT(*) FROM dim_customer
UNION ALL
SELECT 'dim_cashier', COUNT(*) FROM dim_cashier;
