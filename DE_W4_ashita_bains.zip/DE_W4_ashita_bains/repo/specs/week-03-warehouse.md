﻿# Week 3 Data Model Specification

## 1. Purpose

Design a dimensional data warehouse for the RetailCo transaction dataset. The warehouse will support sales analysis by date, store, product, category, customer, region, and payment method.

## 2. Source Dataset

Source file: `retailco_raw_20240115.csv`

Observed dataset size: 52 rows and 16 columns.

The source contains transaction identifiers, store details, transaction dates, customer identifiers, product details, quantities, prices, amounts, discounts, payment methods, cashier identifiers, regions, and cities.

## 3. Proposed Grain

The proposed grain of the fact table is one source record per recorded transaction.

The source contains a `transaction_id`, but the uniqueness of this identifier must be verified before it is used as a key. If a transaction can contain multiple product lines, the grain must be revised to one transaction-product line.

## 4. Proposed Fact Table

Table: `fact_sales`

Measures:
- `quantity`
- `unit_price_inr`
- `total_amount_inr`
- `discount_pct`

Identifiers and relationships:
- Transaction identifier
- Date key
- Store key
- Product key
- Customer key, where available
- Cashier key, where available
- Payment method

## 5. Proposed Dimensions

### Dim Date
Stores the transaction date and calendar attributes such as day, month, quarter, and year.

### Dim Store
Stores the store identifier, store name, city, and region.

### Dim Product
Stores the product code, product name, and category.

### Dim Customer
Stores the available customer identifier. Customer attributes are not present in the source dataset.

### Dim Cashier
Stores the available cashier identifier. Cashier attributes are not present in the source dataset.

Payment method may be represented as a descriptive attribute or a separate dimension, depending on the final schema design.

## 6. Business Questions

The model should support these proposed analytical questions:

1. What is the total recorded sales amount by date?
2. Which stores and cities have the highest recorded sales?
3. Which product categories contribute the most sales?
4. What quantities and sales amounts are recorded for each product?
5. How do recorded sales vary by region?
6. What is the distribution of transactions by payment method?
7. What are the recorded sales totals by month and quarter?

These questions are inferred from the available source columns and should be confirmed against the capstone requirements.

## 7. Data Quality Observations

The initial inspection identified:

- 52 rows and 16 columns.
- Two missing customer identifiers.
- Two missing cashier identifiers.
- Two exact duplicate rows.
- Multiple transaction date formats.

The transformation must standardize valid dates, document missing identifiers, and detect duplicates. Duplicate removal must be explicitly defined and validated before it is applied.

## 8. Key and Integrity Rules

- Verify the uniqueness of `transaction_id`.
- Use primary keys for warehouse dimensions and facts as appropriate.
- Use foreign keys or equivalent validation checks to verify dimension relationships.
- Preserve missing customer and cashier information as unknown rather than inventing identifiers.
- Validate the transformed output against documented expected results.

## 9. Validation Requirements

Document checks for:

- Source and output row counts.
- Duplicate records.
- Missing identifiers.
- Valid transaction dates.
- Dimension-key integrity.
- Sales totals and quantity reconciliation.
- Expected results for representative analytical queries.

## 10. Implementation Status

This document describes the proposed model. The final grain, key design, schema, transformation SQL, and validation results must be confirmed during implementation.
