
-- Week 3: RetailCo Data Warehouse Validation
-- Database: PostgreSQL

-- 1. Row-count reconciliation
SELECT
    (SELECT COUNT(*) FROM staging_retailco) AS staging_rows,
    (SELECT COUNT(*) FROM transformed_retailco) AS transformed_rows,
    (SELECT COUNT(*) FROM fact_sales) AS fact_rows;

-- 2. Duplicate transaction IDs in source
SELECT transaction_id, COUNT(*) AS occurrences
FROM staging_retailco
GROUP BY transaction_id
HAVING COUNT(*) > 1
ORDER BY transaction_id;

-- 3. Invalid or missing dates after transformation
SELECT COUNT(*) AS invalid_dates
FROM transformed_retailco
WHERE transaction_date IS NULL;

-- 4. Missing customer and cashier IDs in source
SELECT
    COUNT(*) FILTER (
        WHERE customer_id IS NULL OR TRIM(customer_id) = ''
    ) AS missing_customers,
    COUNT(*) FILTER (
        WHERE cashier_id IS NULL OR TRIM(cashier_id) = ''
    ) AS missing_cashiers
FROM staging_retailco;

-- 5. Fact-table dimension reference validation
SELECT
    COUNT(*) FILTER (WHERE d.date_key IS NULL) AS missing_dates,
    COUNT(*) FILTER (WHERE s.store_key IS NULL) AS missing_stores,
    COUNT(*) FILTER (WHERE p.product_key IS NULL) AS missing_products
FROM fact_sales f
LEFT JOIN dim_date d ON f.date_key = d.date_key
LEFT JOIN dim_store s ON f.store_key = s.store_key
LEFT JOIN dim_product p ON f.product_key = p.product_key;

-- 6. Sales and quantity summary
SELECT
    COUNT(*) AS fact_rows,
    SUM(quantity) AS total_quantity,
    SUM(total_amount_inr) AS total_sales_inr
FROM fact_sales;

-- 7. Reconcile transformed sales with fact sales
SELECT
    (SELECT SUM(total_amount_inr)
     FROM transformed_retailco) AS transformed_sales_total,
    (SELECT SUM(total_amount_inr)
     FROM fact_sales) AS fact_sales_total;
