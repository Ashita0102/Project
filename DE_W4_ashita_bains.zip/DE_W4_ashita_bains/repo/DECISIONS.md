﻿# Week 4 Technical Decisions

## 1. Repository Integration
The Week 2 ingestion and Week 3 warehouse histories were integrated using Git. Both histories are preserved in the merge commit.

## 2. Ingestion
The existing Week 2 Python ingestion pipeline was retained. It validates the required CSV columns, normalizes transaction dates, reports duplicate rows and missing identifiers, and writes a staging CSV.

## 3. Source Data
The RetailCo source CSV contains 52 rows and 16 columns. The generated Week 4 staging CSV was verified to contain 52 rows and 16 columns.

## 4. Database
PostgreSQL 18 and the existing retailco_dw database are used for the warehouse implementation. MySQL compatibility is not claimed because the Week 3 implementation was executed using PostgreSQL.

## 5. Duplicate Records
The source contains duplicate rows and repeated transaction IDs. The ingestion pipeline reports duplicate rows without removing them. The warehouse preserves source rows using source row numbers.

## 6. Missing Identifiers
Missing customer and cashier identifiers are retained as missing values. The pipeline does not invent identifiers for these records.

## 7. Warehouse Validation
The validation script reported 52 staging rows, 52 transformed rows, and 52 fact rows. Invalid dates and missing date, store, and product references were zero. Total quantity was 121 and total sales were INR 130473.00. Transformed and fact-table sales totals matched.

## 8. Execution Safety
The existing Week 3 warehouse was already populated. Validation was run before attempting a fresh load to avoid accidentally duplicating existing data.

## 9. End-to-End Verification
A fresh, reproducible execution of the complete integrated workflow must be recorded separately. Existing warehouse validation alone is not treated as proof of a fresh end-to-end run.
