# Week 2 Decisions

## Decision: Validate Required Columns

What I was trying to do:
Ensure that the input CSV contains all required RetailCo fields before processing.

What I decided:
Validate the required column names before continuing with ingestion.

Did an AI assistant help here?
Yes.

What it suggested:
Use a list of expected columns and compare it with the input DataFrame columns.

What I changed or kept, and why:
I kept this approach because it provides a clear validation step and reports missing columns.

How I checked it was correct:
The pytest suite includes a test for missing columns.

## Decision: Normalize Transaction Dates

What I was trying to do:
Handle different date formats present in the source data.

What I decided:
Convert transaction dates into the standard YYYY-MM-DD format.

Did an AI assistant help here?
Yes.

What it suggested:
Use pandas date parsing with mixed-format support.

What I changed or kept, and why:
I kept the approach because the source data contains more than one date format.

How I checked it was correct:
The date normalization test verifies that different input formats produce the same standardized date.

## Decision: Handle Duplicate Rows

What I was trying to do:
Determine how duplicate records should be handled.

What I decided:
Detect and report duplicate rows but retain them in the staging output until the business rule is confirmed.

Did an AI assistant help here?
Yes.

What it suggested:
Detect duplicates and either remove or retain them based on a defined business rule.

What I changed or kept, and why:
I chose to retain duplicates because there was no confirmed business rule requiring their removal.

How I checked it was correct:
The ingestion run reports the duplicate count and the test verifies that duplicate records are retained.

## Decision: Testing

What I was trying to do:
Verify that the ingestion pipeline behaves correctly.

What I decided:
Use pytest for automated tests covering validation, dates, missing files, and duplicates.

Did an AI assistant help here?
Yes.

What it suggested:
Create focused unit tests for the individual ingestion functions.

What I changed or kept, and why:
I kept the focused tests because they make individual pipeline behaviours easy to verify.

How I checked it was correct:
The test suite completed successfully with 5 passed tests.

## Decision: Git Repository Hygiene

What I was trying to do:
Prevent generated Python files from being committed.

What I decided:
Use .gitignore to exclude Python cache and pytest cache files.

Did an AI assistant help here?
Yes.

What it suggested:
Ignore __pycache__, *.pyc, and .pytest_cache.

What I changed or kept, and why:
I kept these exclusions because they are generated files and are not required source files.

How I checked it was correct:
git status shows a clean working tree without generated cache files.