# RetailCo Data Ingestion Pipeline

## Overview

This project implements a Python-based data ingestion pipeline for RetailCo transaction data.

The pipeline reads a CSV file, validates the required columns, normalizes transaction dates, detects duplicate rows, reports missing customer and cashier IDs, and writes the processed data to a staging CSV file.

## Input

The input is a RetailCo transaction CSV file containing:

- transaction_id
- store_id
- store_name
- transaction_date
- customer_id
- product_code
- product_name
- category
- quantity
- unit_price_inr
- total_amount_inr
- discount_pct
- payment_method
- cashier_id
- region
- city

## Processing

The pipeline performs the following steps:

1. Reads the input CSV.
2. Validates the required columns.
3. Normalizes transaction dates to `YYYY-MM-DD`.
4. Detects and reports duplicate rows.
5. Reports missing customer IDs.
6. Reports missing cashier IDs.
7. Writes the processed data to a staging CSV file.
8. Reports successful completion.

## Running the Pipeline

From the `repo` directory:

```bash
python ingest.py ..\data\retailco_raw_20240115.csv ..\staging\retailco_staging.csv