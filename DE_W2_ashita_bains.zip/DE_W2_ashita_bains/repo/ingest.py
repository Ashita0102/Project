import argparse
from pathlib import Path

import pandas as pd

EXPECTED_COLUMNS = [
    "transaction_id",
    "store_id",
    "store_name",
    "transaction_date",
    "customer_id",
    "product_code",
    "product_name",
    "category",
    "quantity",
    "unit_price_inr",
    "total_amount_inr",
    "discount_pct",
    "payment_method",
    "cashier_id",
    "region",
    "city",
]


def validate_columns(df):
    missing_columns = [
        column for column in EXPECTED_COLUMNS
        if column not in df.columns
    ]

    if missing_columns:
        raise ValueError(
            f"Missing required columns: {missing_columns}"
        )


def normalize_dates(df):
    dates = pd.to_datetime(
        df["transaction_date"],
        format="mixed",
        errors="coerce"
    )

    if dates.isna().any():
        raise ValueError("Invalid transaction_date values found")

    df["transaction_date"] = dates.dt.strftime("%Y-%m-%d")

    return df


def handle_duplicates(df):
    duplicate_count = df.duplicated().sum()

    print(f"Duplicate rows detected: {duplicate_count}")

    return df


def report_missing_identifiers(df):
    missing_customer = df["customer_id"].isna().sum()
    missing_cashier = df["cashier_id"].isna().sum()

    print(f"Missing customer IDs: {missing_customer}")
    print(f"Missing cashier IDs: {missing_cashier}")


def read_source(input_path):
    path = Path(input_path)

    if not path.exists():
        raise FileNotFoundError(
            f"Input file not found: {input_path}"
        )

    if path.stat().st_size == 0:
        raise ValueError("Input file is empty")

    return pd.read_csv(path)


def write_output(df, output_path):
    output = Path(output_path)

    output.parent.mkdir(parents=True, exist_ok=True)

    df.to_csv(output, index=False)

    print(f"Output written to: {output}")


def run_ingestion(input_path, output_path):
    print(f"Reading input: {input_path}")

    df = read_source(input_path)

    print(f"Rows read: {len(df)}")

    validate_columns(df)

    df = normalize_dates(df)

    handle_duplicates(df)

    report_missing_identifiers(df)

    write_output(df, output_path)

    print("Ingestion completed successfully.")


def main():
    parser = argparse.ArgumentParser(
        description="RetailCo CSV ingestion pipeline"
    )

    parser.add_argument(
        "input",
        help="Path to the input CSV file"
    )

    parser.add_argument(
        "output",
        help="Path to the staging output CSV file"
    )

    args = parser.parse_args()

    try:
        run_ingestion(args.input, args.output)
    except (FileNotFoundError, ValueError) as error:
        print(f"ERROR: {error}")
        raise SystemExit(1)


if __name__ == "__main__":
    main()