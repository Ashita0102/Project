# RetailCo Data Ingestion Specification

## 1. Purpose

The purpose of this ingestion pipeline is to read the
RetailCo raw transaction CSV, validate the input data,
normalize the required fields, and produce a staging
output for downstream processing.

## 2. Input

The pipeline accepts a RetailCo transaction CSV file.

Expected columns:

- transaction_id
- store_id
- store_name
- transaction_date
- customer_id
- product_code
- product_name
- category
- quantity
- unit_price_inr
- total_amount_inr
- discount_pct
- payment_method
- cashier_id
- region
- city

The input file path must be provided to the ingestion
script.

## 3. Output

The pipeline produces a staging CSV containing the
successfully processed RetailCo transaction records.

The output path must be provided to the ingestion script.

The output should preserve the expected transaction
columns and use a consistent date representation.

## 4. Processing

The ingestion pipeline will:

1. Check that the input file exists.
2. Read the CSV file.
3. Validate that the expected columns are present.
4. Parse the transaction date into a consistent format.
5. Validate the required transaction fields.
6. Handle records containing missing optional identifiers.
7. Detect duplicate records.
8. Write the processed records to the staging output.
9. Report the ingestion result.

## 5. Data-Specific Edge Cases

The input data contains the following cases that the
ingestion pipeline must account for:

### Missing customer IDs

Some records have a missing customer_id.

The pipeline must not crash because of a missing
customer identifier.

### Missing cashier IDs

Some records have a missing cashier_id.

The pipeline must not crash because of a missing
cashier identifier.

### Duplicate records

The input contains duplicate rows.

The ingestion behaviour for duplicates must be
explicitly handled and documented.

### Inconsistent transaction date formats

The input contains transaction dates represented
using different formats, including:

- YYYY-MM-DD
- DD-MM-YYYY

The ingestion pipeline must normalize valid dates
to one consistent representation.

### Missing input file

If the supplied input path does not exist, the
pipeline must report the error clearly.

### Invalid input structure

If the expected columns are missing, the pipeline
must report a validation error instead of silently
continuing.

### Empty input

An empty input file must be detected and reported
appropriately.

## 6. Error Handling

The pipeline should use explicit error handling for
expected failures.

It should not silently ignore input or processing
errors.

Errors should provide enough information to identify
the problem.

## 7. Success Criteria

The ingestion is successful when:

- The input CSV can be read.
- All expected columns are validated.
- Valid transaction dates are normalized.
- Data-quality issues are handled according to the
  defined rules.
- The staging output is created.
- The output can be read successfully.
- The script exits successfully for valid input.

## 8. Testing

Tests should cover at least:

1. Valid input.
2. Missing input file.
3. Empty input.
4. Missing expected columns.
5. Inconsistent transaction date formats.
6. Missing customer identifiers.
7. Missing cashier identifiers.
8. Duplicate records.