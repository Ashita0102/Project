import pandas as pd
import pytest 

from ingest import (
    handle_duplicates,
    normalize_dates,
    read_source,
    validate_columns,
)


def test_validate_columns():
    df = pd.DataFrame({
        "transaction_id": ["T001"],
        "store_id": ["S001"],
        "store_name": ["Store A"],
        "transaction_date": ["2024-01-15"],
        "customer_id": ["C001"],
        "product_code": ["P001"],
        "product_name": ["Product A"],
        "category": ["Category A"],
        "quantity": [2],
        "unit_price_inr": [100],
        "total_amount_inr": [200],
        "discount_pct": [10],
        "payment_method": ["UPI"],
        "cashier_id": ["CA001"],
        "region": ["North"],
        "city": ["Delhi"],
    })

    validate_columns(df)


def test_missing_column():
    df = pd.DataFrame({
        "transaction_id": ["T001"]
    })

    with pytest.raises(ValueError):
        validate_columns(df)


def test_normalize_dates():
    df = pd.DataFrame({
        "transaction_date": [
            "2024-01-15",
            "15-01-2024",
        ]
    })

    result = normalize_dates(df)

    assert result["transaction_date"].tolist() == [
        "2024-01-15",
        "2024-01-15",
    ]


def test_missing_file():
    with pytest.raises(FileNotFoundError):
        read_source("file_that_does_not_exist.csv")


def test_duplicate_detection():
    df = pd.DataFrame({
        "transaction_id": ["T001", "T001"],
        "store_id": ["S001", "S001"],
    })

    result = handle_duplicates(df)

    assert len(result) == 2