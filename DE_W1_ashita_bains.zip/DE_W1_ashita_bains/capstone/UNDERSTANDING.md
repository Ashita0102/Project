# Capstone Understanding

## 1. Business Context
The provided dataset contains retail transaction
information from multiple stores. It includes
customer, product, pricing, discount, payment
and geographical details.

## 2. Initial Understanding
The dataset can be used to study retail sales,
customer purchasing patterns, product
performance and store-level transactions.

The exact business objective and expected
deliverables are yet to be confirmed with
the capstone mentor.

## 3. Available Data
The provided CSV includes:
- Transaction details
- Customer and store identifiers
- Product information
- Quantity and pricing
- Discounts and payment methods
- Region and city

## 4. Initial Discovery Questions
- What is the main business problem?
- Who will use the final solution?
- What are the expected outputs?
- Is the data complete and representative?
- Are there any business or technical constraints?

## 5. Initial Approach
First, inspect the dataset and understand
its structure, data types, missing values
and inconsistencies.

Then, confirm the business requirements
before finalizing the solution design.

## 6. Pending Clarifications
The exact project objective, success criteria,
expected deliverables and client requirements
are pending confirmation.