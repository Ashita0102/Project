# Week 1 STATUS

Name: Ashita Bains
GitLab username: Pending
Office:Not finalized

## Environment
Dev environment set up and verified: No
Cloud access verified: No
ENV_CHECK.txt produced from a live run: No

## Handover repo work
DIAGNOSIS.md committed BEFORE any fix: No
Pull request opened and merged: No
Fix summary: Pending handover repository access.

## AI assistant use
Assistants used: ChatGPT
DECISIONS.md records where they helped: In progress
AI suggestion and review: Documenting and verifying
suggestions before accepting them.

## HackerEarth checks
Linux/shell skills check completed: Yes
AI responsible-use quiz completed: Yes

## Capstone
capstone/UNDERSTANDING.md written: Draft

## Self-assessment
Confident: Initial project documentation and
local environment preparation.
Working on: Git workflow, repository diagnosis
and capstone requirements.
Not finished: GitLab-dependent tasks are
pending access.