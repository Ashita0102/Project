# Decisions

## Decision: Local Development Setup

What I was trying to do:
Prepare the Week 1 project locally while
GitLab access is pending.

What I decided:
Use VS Code, Git and Python on Windows.

Did an AI assistant help here? Yes

If yes: what it suggested:
A local-first setup and an organized
submission folder structure.

What I changed or kept, and why:
Followed the local setup approach to
prepare the files without GitLab access.

How I checked it was actually correct:
Verify the installed tools and folder
structure on the local machine.